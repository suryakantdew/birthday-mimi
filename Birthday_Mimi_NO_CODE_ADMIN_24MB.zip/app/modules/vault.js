console.log("Vault Module Loaded 🔓");

const Vault = {

    unlocked: false,

    attempts: 0

};

function lockVault() {

    const card = document.querySelector(".vault");

    if (!card) return;

    card.classList.remove("vault-unlock");
    card.classList.add("vault-lock");

}

function unlockVault() {

    const card = document.querySelector(".vault");

    if (!card) return;

    card.classList.remove("vault-lock");
    card.classList.add("vault-unlock");

}