const express = require("express");
const path = require("path");
const fs = require("fs");
const crypto = require("crypto");

const app = express();
const PORT = process.env.PORT || 10000;
const ROOT = path.resolve(__dirname, "..");
const DATA_DIR = path.join(__dirname, "data");
const WISH_FILE = path.join(DATA_DIR, "wishes.json");
const BACKUP_DIR = path.join(DATA_DIR, "backups");
const ADMIN_TOKEN = process.env.MIMI_ADMIN_TOKEN || "";
const CONFIG_FILE = path.join(ROOT, "data", "config.json");

fs.mkdirSync(DATA_DIR, { recursive: true });
fs.mkdirSync(BACKUP_DIR, { recursive: true });
if (!fs.existsSync(WISH_FILE)) fs.writeFileSync(WISH_FILE, "[]", "utf8");
if (!fs.existsSync(CONFIG_FILE)) fs.writeFileSync(CONFIG_FILE, JSON.stringify({password:"mimi",site:{},theme:{},controls:{},text:{}},null,2), "utf8");

app.disable("x-powered-by");
app.use(express.json({ limit: "1mb" }));


function readConfig(){ try { const c=JSON.parse(fs.readFileSync(CONFIG_FILE,"utf8")); return c && typeof c === "object" ? c : {}; } catch { return {}; } }
function writeConfig(c){ fs.writeFileSync(CONFIG_FILE, JSON.stringify(c,null,2), "utf8"); }
function safeAsset(input){
  if(typeof input!=="string" || !input.trim()) return null;
  const n=path.posix.normalize(input.replace(/\\/g,"/")).replace(/^\.\//,"");
  if(n.startsWith("../") || n.startsWith("/") || !n.startsWith("assets/")) return null;
  const ext=path.extname(n).toLowerCase();
  if(![".png",".jpg",".jpeg",".webp",".gif",".mp4",".webm",".wav",".mp3",".svg"].includes(ext)) return null;
  return n;
}
function listAssets(){
  const out=[];
  function walk(dir,rel){ if(!fs.existsSync(dir)) return; for(const e of fs.readdirSync(dir,{withFileTypes:true})){ const cr=rel?`${rel}/${e.name}`:e.name; const p=path.join(dir,e.name); if(e.isDirectory()) walk(p,cr); else { const ext=path.extname(e.name).toLowerCase(); if([".png",".jpg",".jpeg",".webp",".gif",".mp4",".webm",".wav",".mp3",".svg"].includes(ext)) out.push({path:cr,size:fs.statSync(p).size}); } } }
  walk(path.join(ROOT,"assets"),"assets"); return out.sort((a,b)=>a.path.localeCompare(b.path));
}

function readWishes() {
  try {
    const parsed = JSON.parse(fs.readFileSync(WISH_FILE, "utf8"));
    return Array.isArray(parsed) ? parsed : [];
  } catch { return []; }
}
function writeWishes(wishes) { fs.writeFileSync(WISH_FILE, JSON.stringify(wishes, null, 2), "utf8"); }
function authorized(req) {
  const header = req.get("authorization") || "";
  const token = header.startsWith("Bearer ") ? header.slice(7).trim() : "";
  return !!ADMIN_TOKEN && token === ADMIN_TOKEN;
}
function localReply() {
  return "Aapne jo wish maangi hai na… ✨\n\nmaine use dil mein rakh liya hai.\n\nAapne mujhse maanga hai,\nto use main zaroor poora karunga. 🤍\n\nAap bas wish maangiye, Mimi…\nuse sach karne ki poori koshish meri hogi. 🌙✨\n\nAur jab woh poori hogi,\naapki smile hi meri sabse badi khushi hogi. 🤍";
}

// Only website source/config files are editable from the private panel.
const EDIT_ROOTS = ["app", "css/screens", "js/screens", "data"];
const EDIT_EXT = new Set([".html", ".css", ".js", ".json", ".txt", ".md"]);
function safeRelative(input) {
  if (typeof input !== "string" || !input.trim()) return null;
  const normalized = path.posix.normalize(input.replace(/\\/g, "/")).replace(/^\.\//, "");
  if (normalized.startsWith("../") || normalized.includes("/../") || normalized.startsWith("/")) return null;
  const ext = path.extname(normalized).toLowerCase();
  if (!EDIT_EXT.has(ext)) return null;
  if (!EDIT_ROOTS.some(root => normalized === root || normalized.startsWith(root + "/"))) return null;
  return normalized;
}
function absFor(rel) { return path.join(ROOT, rel); }
function listEditableFiles() {
  const out = [];
  function walk(dir, rel) {
    if (!fs.existsSync(dir)) return;
    for (const entry of fs.readdirSync(dir, { withFileTypes: true })) {
      const childRel = rel ? `${rel}/${entry.name}` : entry.name;
      const child = path.join(dir, entry.name);
      if (entry.isDirectory()) walk(child, childRel);
      else if (EDIT_EXT.has(path.extname(entry.name).toLowerCase())) {
        out.push({ path: childRel, size: fs.statSync(child).size });
      }
    }
  }
  for (const root of EDIT_ROOTS) walk(path.join(ROOT, root), root);
  return out.sort((a,b) => a.path.localeCompare(b.path));
}

app.get("/", (_req, res) => res.redirect("/app/index.html"));
app.get("/health", (_req, res) => res.json({ ok: true, service: "PROJECT MIMI" }));

app.post("/api/wish", (req, res) => {
  const wish = typeof req.body?.wish === "string" ? req.body.wish.trim() : "";
  if (wish.length < 2 || wish.length > 500) return res.status(400).json({ error: "Wish must be between 2 and 500 characters." });
  const reply = localReply();
  const wishes = readWishes();
  wishes.push({ id: `${Date.now()}-${Math.random().toString(36).slice(2, 8)}`, wish, reply, status: "new", adminReply: "", createdAt: new Date().toISOString(), updatedAt: new Date().toISOString() });
  writeWishes(wishes);
  res.json({ ok: true, reply });
});

app.use("/api/admin", (req, res, next) => {
  if (!authorized(req)) return res.status(401).json({ error: "Invalid admin access key" });
  next();
});

app.get("/api/admin/dashboard", (_req, res) => {
  const wishes = readWishes();
  res.json({ stats: { total: wishes.length, new: wishes.filter(x => x.status === "new").length, read: wishes.filter(x => x.status === "read").length, replied: wishes.filter(x => x.status === "replied").length }, files: listEditableFiles().length });
});
app.get("/api/wishes", (_req, res) => res.json({ wishes: readWishes().slice().reverse() }));
app.patch("/api/wishes/:id", (req, res) => {
  const wishes = readWishes();
  const item = wishes.find(x => x.id === req.params.id);
  if (!item) return res.status(404).json({ error: "Wish not found" });
  if (typeof req.body?.status === "string" && ["new", "read", "replied"].includes(req.body.status)) item.status = req.body.status;
  if (typeof req.body?.adminReply === "string") { item.adminReply = req.body.adminReply.slice(0, 2000); if (item.adminReply.trim()) item.status = "replied"; }
  item.updatedAt = new Date().toISOString();
  writeWishes(wishes);
  res.json({ ok: true, wish: item });
});
app.delete("/api/wishes/:id", (req, res) => {
  const wishes = readWishes();
  const next = wishes.filter(x => x.id !== req.params.id);
  if (next.length === wishes.length) return res.status(404).json({ error: "Wish not found" });
  writeWishes(next); res.json({ ok: true });
});

app.get("/api/admin/files", (_req, res) => res.json({ files: listEditableFiles() }));
app.get("/api/admin/file", (req, res) => {
  const rel = safeRelative(req.query.path);
  if (!rel) return res.status(400).json({ error: "File is not editable" });
  const file = absFor(rel);
  if (!fs.existsSync(file) || !fs.statSync(file).isFile()) return res.status(404).json({ error: "File not found" });
  res.json({ path: rel, content: fs.readFileSync(file, "utf8") });
});
app.put("/api/admin/file", (req, res) => {
  const rel = safeRelative(req.body?.path);
  if (!rel || typeof req.body?.content !== "string") return res.status(400).json({ error: "Invalid file or content" });
  if (req.body.content.length > 2_000_000) return res.status(413).json({ error: "File is too large" });
  const file = absFor(rel);
  if (!fs.existsSync(file)) return res.status(404).json({ error: "File not found" });
  const backup = path.join(BACKUP_DIR, `${Date.now()}-${rel.replace(/[^a-zA-Z0-9._-]/g, "_")}`);
  try { fs.copyFileSync(file, backup); } catch {}
  fs.writeFileSync(file, req.body.content, "utf8");
  res.json({ ok: true, path: rel, savedAt: new Date().toISOString(), backup: path.relative(ROOT, backup) });
});


app.get("/api/admin/config", (_req,res)=>res.json(readConfig()));
app.put("/api/admin/config", (req,res)=>{
  const incoming=req.body && typeof req.body==="object" ? req.body : null;
  if(!incoming) return res.status(400).json({error:"Invalid settings"});
  const current=readConfig();
  const next={...current, ...incoming, site:{...(current.site||{}),...(incoming.site||{})}, theme:{...(current.theme||{}),...(incoming.theme||{})}, controls:{...(current.controls||{}),...(incoming.controls||{})}, text:{...(current.text||{}),...(incoming.text||{})}};
  if(typeof next.password!=="string" || next.password.length<1 || next.password.length>100) return res.status(400).json({error:"Invalid password"});
  if(next.site && typeof next.site.whatsappNumber==="string") next.site.whatsappNumber=next.site.whatsappNumber.replace(/[^0-9]/g,"").slice(0,20);
  writeConfig(next); res.json({ok:true,config:next});
});
app.get("/api/admin/screen", (req,res)=>{
  const name=String(req.query.name||"").replace(/[^a-zA-Z0-9_-]/g,"");
  const allowed=["boot","password","movieIntro","journey","memoryScan","memory1","memory2","memory3","memoryVault","personalMessage","surprise1","surprise2","surprise3","surprise4","surprise5","gardenGate","wishGarden","surprise8","birthdayCake","finalSurprise","emotionalEnding"];
  if(!allowed.includes(name)) return res.status(400).json({error:"Screen not editable"});
  const p=path.join(ROOT,"app",name+".html"); if(!fs.existsSync(p)) return res.status(404).json({error:"Screen not found"});
  res.json({name,content:fs.readFileSync(p,"utf8")});
});
app.put("/api/admin/screen", (req,res)=>{
  const name=String(req.body?.name||"").replace(/[^a-zA-Z0-9_-]/g,"");
  const allowed=["boot","password","movieIntro","journey","memoryScan","memory1","memory2","memory3","memoryVault","personalMessage","surprise1","surprise2","surprise3","surprise4","surprise5","gardenGate","wishGarden","surprise8","birthdayCake","finalSurprise","emotionalEnding"];
  if(!allowed.includes(name) || typeof req.body?.content!=="string") return res.status(400).json({error:"Invalid screen"});
  if(req.body.content.length>2_000_000) return res.status(413).json({error:"Screen is too large"});
  const p=path.join(ROOT,"app",name+".html"); if(!fs.existsSync(p)) return res.status(404).json({error:"Screen not found"});
  const backup=path.join(BACKUP_DIR,`${Date.now()}-${name}.html`); try{fs.copyFileSync(p,backup)}catch{}
  fs.writeFileSync(p,req.body.content,"utf8"); res.json({ok:true,savedAt:new Date().toISOString()});
});
app.get("/api/admin/assets", (_req,res)=>res.json({assets:listAssets()}));
app.post("/api/admin/asset-replace", (req,res)=>{
  const target=safeAsset(req.body?.target); const data=String(req.body?.data||"");
  if(!target || !data.startsWith("data:")) return res.status(400).json({error:"Invalid asset"});
  const m=data.match(/^data:[^;]+;base64,(.+)$/s); if(!m) return res.status(400).json({error:"Invalid upload"});
  const buf=Buffer.from(m[1],"base64"); if(buf.length>25*1024*1024) return res.status(413).json({error:"Asset is larger than 25MB"});
  const p=path.join(ROOT,target); if(!fs.existsSync(p)) return res.status(404).json({error:"Target asset not found"});
  const backup=path.join(BACKUP_DIR,`${Date.now()}-${path.basename(target)}`); try{fs.copyFileSync(p,backup)}catch{}
  fs.writeFileSync(p,buf); res.json({ok:true,path:target,size:buf.length});
});

app.use(express.static(ROOT, { extensions: ["html"], index: false, setHeaders(res) { res.setHeader("Cache-Control", "no-cache"); } }));
app.listen(PORT, "0.0.0.0", () => console.log(`PROJECT MIMI live on port ${PORT}`));
