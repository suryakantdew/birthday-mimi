# Project MIMI — Wish Garden AI Setup

## What this adds
- 5 flower discovery
- Private wish input addressed with “aap”
- Server-side AI reply in Surya's first-person best-friend tone
- Original wish + generated reply stored privately on the server
- Password/token-protected admin panel
- Testable directly from the existing Hidden Test Mode

## Important
The SPCK/static preview alone cannot securely call the AI API or protect the admin data. Run the included Node server or deploy it to a server/host.

## Local/server setup
1. Install Node.js 18+.
2. Open `server/` in a terminal.
3. Run `npm install`.
4. Copy `.env.example` to `.env` and set `OPENAI_API_KEY` and a long random `MIMI_ADMIN_TOKEN`.
5. Export the variables in your hosting environment (or use a dotenv loader if you add one). The server intentionally does not read `.env` automatically.
6. Run `npm start`.
7. Open `http://localhost:3000/app/index.html`.
8. Admin: `http://localhost:3000/app/admin.html` and enter `MIMI_ADMIN_TOKEN`.

For production, use HTTPS and a persistent database rather than a local JSON file if the host has ephemeral storage.

## If using SPCK on a phone
Keep the project files in SPCK for editing, but the AI/admin backend must be reachable at a public HTTPS URL. Then change `window.MIMI_WISH_API` in `js/core/wishConfig.js` to that backend's `/api/wish` URL.

Do not put the OpenAI API key in HTML, CSS, or browser JavaScript.
