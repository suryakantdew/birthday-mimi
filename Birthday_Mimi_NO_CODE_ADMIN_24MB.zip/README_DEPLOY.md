# PROJECT MIMI — Live deployment

Complete Birthday MIMI website plus Node/Express live server and private Wish Garden admin API.

## Render
- Build command: `npm install`
- Start command: `npm start`
- Health check: `/health`
- Website: `/app/index.html`
- Admin panel: `/app/admin.html`
- Required environment variable: `MIMI_ADMIN_TOKEN`

The existing cinematic screens/assets are preserved. The Wish Garden uses `/api/wish` when deployed and falls back to its local reply behavior if the API is unavailable.

## Private Admin Control Room
Set the Render environment variable `MIMI_ADMIN_TOKEN` to a strong secret. `/app/admin.html` provides dashboard stats, Wish Garden management (reply/read/delete), and a **Full Edit** source editor for editable HTML/CSS/JS/JSON files under the safe project directories. Locked engine/final assets are not exposed through the editor.
