const Screen = {
    
    current: null,
    
    async load(name) {
        
        console.log("Loading Screen :", name);
        
        const container = document.getElementById("screenContainer");
        
        if (!container) {
            
            console.error("screenContainer Not Found");
            
            return;
            
        }
        
        try {
            
            const response = await fetch(name + ".html");
            
            const html = await response.text();
            
            container.innerHTML = html;
            
            this.current = name;
            
            console.log(name + " Loaded");
            
            if (typeof window["init" + name] === "function") {
                
                window["init" + name]();
                
            }
            
        }
        
        catch (err) {
            
            console.error(err);
            
        }
        
    }
    
};