/* ==========================================
   PROJECT MIMI - UTILS
========================================== */

const Utils = {

    // Wait
    wait(ms){
        return new Promise(resolve=>setTimeout(resolve,ms));
    },

    // Random Integer
    random(min,max){
        return Math.floor(
            Math.random()*(max-min+1)
        )+min;
    },

    // Clamp Number
    clamp(value,min,max){
        return Math.min(
            Math.max(value,min),
            max
        );
    },

    // Query Selector
    $(selector){
        return document.querySelector(selector);
    },

    // Query Selector All
    $$(selector){
        return document.querySelectorAll(selector);
    }

};