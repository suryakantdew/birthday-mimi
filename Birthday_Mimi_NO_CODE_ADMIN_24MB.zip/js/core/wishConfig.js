/* =========================================================
   PROJECT MIMI — WISH API CONFIG
   Local/Test mode: no backend required.
   Later, set window.MIMI_WISH_API to the HTTPS /api/wish URL.
========================================================= */

window.MIMI_WISH_API = window.MIMI_WISH_API || "";
