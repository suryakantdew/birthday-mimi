/* ==========================================
   PROJECT MIMI UI ENGINE
========================================== */

const UI = {

    async fadeIn(element, duration = 600){

        if(!element) return;

        element.style.display = "";

        element.style.opacity = 0;

        element.style.transition =
            `opacity ${duration}ms ease`;

        requestAnimationFrame(()=>{
            element.style.opacity = 1;
        });

        return Utils.wait(duration);

    },

    async fadeOut(element, duration = 600){

        if(!element) return;

        element.style.transition =
            `opacity ${duration}ms ease`;

        element.style.opacity = 0;

        await Utils.wait(duration);

        element.style.display = "none";

    },

    async press(element){

        if(!element) return;

        element.style.transition =
            "transform 120ms ease";

        element.style.transform = "scale(.97)";

        await Utils.wait(120);

        element.style.transform = "scale(1)";

    },

    glow(element){

        if(!element) return;

        element.classList.add("glow");

    },

    removeGlow(element){

        if(!element) return;

        element.classList.remove("glow");

    },

    async scale(element, value = .98, duration = 180){

        if(!element) return;

        element.style.transition =
            `transform ${duration}ms ease`;

        element.style.transform =
            `scale(${value})`;

        await Utils.wait(duration);

    }

};