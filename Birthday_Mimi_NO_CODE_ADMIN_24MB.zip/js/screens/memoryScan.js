async function startMemoryScan() {

    Screens.show("memoryScan");

    const text = document.getElementById("scanText");
    const status = document.getElementById("scanStatus");
    const discovery = document.getElementById("discoveryText");
    const fill = document.getElementById("scanFill");
    const memoryScreen = document.getElementById("memoryScan");
    const stage = document.querySelector(".memory-scan-stage");

    const nodes = [
        document.querySelector(".node-one"),
        document.querySelector(".node-two"),
        document.querySelector(".node-three")
    ];

    memoryScreen.classList.remove("fade");

    if(fill) fill.style.width = "0%";
    nodes.forEach(n => n && n.classList.remove("found"));

    /* Node 01 is the first spark of the archive, so the scene
       starts with a visual anchor instead of a blank constellation. */
    if(nodes[0]){
        setTimeout(()=>nodes[0].classList.add("found"),280);
    }

    const sound = (name,key)=>{
        try{
            if(typeof AudioEngine !== "undefined" &&
               typeof AudioEngine.play === "function"){
                AudioEngine.play(name,key);
            }
        }catch(_){}
    };

    /*
      The Memory Scan title is deliberately stable.
      We animate the world around it instead of repeatedly fading
      the sentence in and out.
    */
    if(text){
        text.innerHTML = "Putting a few memories<br>in the right place...";
    }

    if(status){
        status.textContent = "Some moments are worth finding again.";
    }

    if(discovery){
        discovery.textContent = "SEARCHING QUIETLY...";
    }

    sound("transition","memory-scan-start");

    const stages = [
        {
            at:0,
            status:"Some moments are worth finding again.",
            discovery:"SEARCHING THE ARCHIVE..."
        },
        {
            at:1900,
            status:"A few little moments are waking up.",
            discovery:"MEMORY 01 · FOUND"
        },
        {
            at:3600,
            status:"The little things are still here.",
            discovery:"MEMORY 02 · FOUND"
        },
        {
            at:5200,
            status:"Almost ready. Just one last little piece.",
            discovery:"MEMORY 03 · FOUND"
        }
    ];

    let stageIndex=-1;

    function changeStage(stage,index){
        if(status) status.textContent=stage.status;
        if(discovery) discovery.textContent=stage.discovery;

        if(index>0 && nodes[index-1]){
            nodes[index-1].classList.add("found");
            sound("memory","memory-node-"+index);
        }
    }

    const started=performance.now();
    const total=6800;

    while(true){
        const elapsed=performance.now()-started;
        const progress=Math.min(1,elapsed/total);

        if(fill) fill.style.width=(progress*100)+"%";

        let next=0;
        for(let i=stages.length-1;i>=0;i--){
            if(elapsed>=stages[i].at){
                next=i;
                break;
            }
        }

        if(next!==stageIndex){
            stageIndex=next;
            changeStage(stages[next],next);
        }

        if(progress>=1) break;
        await wait(50);
    }

    if(nodes[2]) nodes[2].classList.add("found");

    if(status){
        status.textContent="The journey starts with a little key.";
    }

    if(discovery){
        discovery.textContent="MEMORY ARCHIVE · READY";
    }

    if(stage){
        stage.classList.add("archive-ready");
    }

    sound("unlock","memory-scan-complete");

    /* Let the completed constellation breathe before leaving. */
    await wait(2250);

    memoryScreen.classList.add("fade");

    await wait(950);

    Engine.loadScreen("password");
}

function wait(ms){
    return new Promise(resolve=>setTimeout(resolve,ms));
}
