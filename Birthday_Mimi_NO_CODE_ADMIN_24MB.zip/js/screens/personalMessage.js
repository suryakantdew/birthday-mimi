/* =========================================================
   PROJECT MIMI — PERSONAL MESSAGE
   PREMIUM PAGE-BY-PAGE HANDWRITTEN TYPING
========================================================= */

async function initPersonalMessage() {

    console.log(
        "Personal Message Loaded"
    );


    /* =====================================================
       SCREEN
    ===================================================== */

    const screen =
        document.getElementById(
            "personalMessage"
        );


    if (!screen) {

        console.warn(
            "Personal Message screen not found"
        );

        return;
    }


    /* =====================================================
       SCROLL CONTAINER
    ===================================================== */

    const scroll =
        screen.querySelector(
            ".personal-scroll"
        );


    /* =====================================================
       ALL LETTER PAGES
    ===================================================== */

    const pages = [
        ...screen.querySelectorAll(
            ".letter-page"
        )
    ];


    if (!pages.length) {

        console.warn(
            "Personal Message pages not found"
        );

        return;
    }


    /* =====================================================
       TYPING SPEED
    ===================================================== */

    const BASE_SPEED = 19;


    function characterDelay(character) {

        if (
            character === "," ||
            character === ";"
        ) {

            return 65;
        }


        if (
            character === ":" 
        ) {

            return 70;
        }


        if (
            character === "."
        ) {

            return 115;
        }


        if (
            character === "!"
        ) {

            return 135;
        }


        if (
            character === "?"
        ) {

            return 125;
        }


        if (
            character === "…"
        ) {

            return 200;
        }


        if (
            character === "\n"
        ) {

            return 30;
        }


        if (
            character === " "
        ) {

            return 9;
        }


        return BASE_SPEED;
    }


    /* =====================================================
       COLLECT TEXT NODES
    ===================================================== */

    function collectTextNodes(content) {

        const walker =
            document.createTreeWalker(

                content,

                NodeFilter.SHOW_TEXT,

                {

                    acceptNode(node) {

                        if (
                            !node.nodeValue ||
                            !node.nodeValue.trim()
                        ) {

                            return NodeFilter.FILTER_REJECT;
                        }


                        const parent =
                            node.parentElement;


                        if (!parent) {

                            return NodeFilter.FILTER_REJECT;
                        }


                        /*
                         * Never type button text.
                         */

                        if (
                            parent.closest(
                                "button"
                            )
                        ) {

                            return NodeFilter.FILTER_REJECT;
                        }


                        /*
                         * Decorative elements
                         * are not part of typing.
                         */

                        if (
                            parent.closest(
                                ".page-art"
                            ) ||
                            parent.closest(
                                ".handwritten-break"
                            )
                        ) {

                            return NodeFilter.FILTER_REJECT;
                        }


                        return NodeFilter.FILTER_ACCEPT;
                    }
                }
            );


        const nodes = [];

        let node;


        while (
            (node = walker.nextNode())
        ) {

            const original =
                node.nodeValue;


            /*
             * Preserve whitespace around
             * the actual text.
             */

            const leading =
                original.match(
                    /^\s*/
                )?.[0] || "";


            const trailing =
                original.match(
                    /\s*$/
                )?.[0] || "";


            const start =
                leading.length;


            const end =
                original.length -
                trailing.length;


            const core =
                original.slice(
                    start,
                    end
                );


            if (!core) {
                continue;
            }


            nodes.push({

                node: node,

                leading: leading,

                trailing: trailing,

                text: core
            });


            /*
             * Keep only the original
             * leading whitespace.
             */

            node.nodeValue =
                leading;
        }


        return nodes;
    }


    /* =====================================================
       PREPARE PAGES
    ===================================================== */

    const pageData = [];


    pages.forEach(
        (page, pageIndex) => {

            const content =
                page.querySelector(
                    ".letter-content"
                );


            if (!content) {
                return;
            }


            const nodes =
                collectTextNodes(
                    content
                );


            if (!nodes.length) {
                return;
            }


            /*
             * Make absolutely sure the
             * page starts hidden.
             */

            page.classList.remove(
                "is-typing"
            );

            page.classList.remove(
                "is-typed"
            );


            /*
             * Hide page-end ornament
             * until typing completes.
             */

            const pageEnd =
                page.querySelector(
                    ".page-end"
                );


            if (pageEnd) {

                pageEnd.style.visibility =
                    "hidden";
            }


            pageData.push({

                page: page,

                nodes: nodes,

                pageIndex: pageIndex,

                typed: false,

                typing: false
            });

        }
    );


    if (!pageData.length) {

        console.warn(
            "No typeable Personal Message content found"
        );

        return;
    }


    /* =====================================================
       TYPE ONE TEXT NODE
    ===================================================== */

    async function typeNode(item) {

        const node =
            item.node;


        /*
         * Reset to leading whitespace
         * before typing.
         */

        node.nodeValue =
            item.leading;


        for (
            let i = 0;
            i < item.text.length;
            i++
        ) {

            const character =
                item.text.charAt(i);


            node.nodeValue +=
                character;


            await wait(
                characterDelay(
                    character
                )
            );
        }


        /*
         * Restore trailing whitespace.
         */

        node.nodeValue +=
            item.trailing;
    }


    /* =====================================================
       TYPE COMPLETE PAGE
    ===================================================== */

    async function typePage(data) {

        if (!data) {
            return;
        }


        if (
            data.typed ||
            data.typing
        ) {

            return;
        }


        data.typing = true;


        const page =
            data.page;


        /* =================================================
           SHOW PAGE CONTENT
        ================================================= */

        page.classList.add(
            "is-typing"
        );


        /*
         * Give CSS transition a frame
         * before characters begin.
         */

        await wait(350);


        /* =================================================
           TYPE CONTENT
        ================================================= */

        for (
            const item of data.nodes
        ) {

            await typeNode(
                item
            );


            /*
             * Small natural pause
             * between text blocks.
             */

            await wait(120);
        }


        /* =================================================
           FINISH PAGE
        ================================================= */

        page.classList.remove(
            "is-typing"
        );


        page.classList.add(
            "is-typed"
        );


        data.typed = true;
        data.typing = false;


        /* =================================================
           SHOW BOTTOM PAGE ORNAMENT
        ================================================= */

        const pageEnd =
            page.querySelector(
                ".page-end"
            );


        if (pageEnd) {

            pageEnd.style.visibility =
                "visible";
        }


        console.log(
            `Personal Message Page ${
                String(data.pageIndex + 1)
                    .padStart(2, "0")
            } Typed`
        );
    }


    /* =====================================================
       FIRST PAGE
    ===================================================== */

    await wait(500);


    await typePage(
        pageData[0]
    );


    /* =====================================================
       INTERSECTION OBSERVER
       Other pages type when they enter view.
    ===================================================== */

    if (
        "IntersectionObserver" in window &&
        scroll
    ) {

        const observer =
            new IntersectionObserver(

                entries => {

                    entries.forEach(
                        entry => {

                            if (
                                !entry.isIntersecting
                            ) {

                                return;
                            }


                            const data =
                                pageData.find(
                                    item =>
                                        item.page ===
                                        entry.target
                                );


                            if (!data) {
                                return;
                            }


                            if (
                                data.typed ||
                                data.typing
                            ) {

                                return;
                            }


                            /*
                             * Type page.
                             */

                            typePage(
                                data
                            );


                            /*
                             * Once triggered,
                             * don't trigger it again.
                             */

                            observer.unobserve(
                                entry.target
                            );

                        }
                    );

                },

                {

                    root: scroll,

                    threshold: 0.22
                }
            );


        pageData.forEach(
            data => {

                /*
                 * First page already typed.
                 */

                if (
                    data.pageIndex !==
                    pageData[0].pageIndex
                ) {

                    observer.observe(
                        data.page
                    );
                }

            }
        );

    } else {

        /*
         * Fallback for browsers without
         * IntersectionObserver.
         */

        for (
            let i = 1;
            i < pageData.length;
            i++
        ) {

            await typePage(
                pageData[i]
            );
        }
    }


    /* =====================================================
       PERSONAL MESSAGE → SURPRISE 1
    ===================================================== */

    const nextButton =
        document.getElementById(
            "personalMessageNext"
        );


    if (nextButton) {

        /*
         * Button stays unavailable
         * until Page 7 is typed.
         */

        nextButton.style.opacity =
            "0";

        nextButton.style.pointerEvents =
            "none";

        nextButton.style.transform =
            "translateY(10px)";


        const finalPage =
            pageData[
                pageData.length - 1
            ];


        /*
         * Watch final page.
         */

        const showFinalButton =
            async () => {

                if (
                    !finalPage ||
                    !finalPage.typed
                ) {

                    return;
                }


                await wait(500);


                nextButton.classList.add(
                    "visible"
                );


                nextButton.style.opacity =
                    "1";

                nextButton.style.pointerEvents =
                    "auto";

                nextButton.style.transform =
                    "translateY(0)";

                nextButton.style.transition =
                    "opacity .7s ease, transform .7s ease";
            };


        /*
         * Check immediately in case
         * Page 7 was already typed.
         */

        if (
            finalPage.typed
        ) {

            await showFinalButton();

        } else {

            /*
             * Small polling watcher only
             * for the final page.
             */

            const finalWatcher =
                setInterval(
                    async () => {

                        if (
                            finalPage.typed
                        ) {

                            clearInterval(
                                finalWatcher
                            );

                            await showFinalButton();
                        }

                    },
                    300
                );
        }


        /* =================================================
           NEXT BUTTON CLICK
        ================================================= */

        nextButton.onclick =
            async () => {

                if (
                    nextButton.disabled
                ) {

                    return;
                }


                nextButton.disabled =
                    true;


                /* Button press */

                nextButton.style.transform =
                    "scale(.96)";


                await wait(120);


                nextButton.style.transform =
                    "translateY(0) scale(1)";


                /* Fade Personal Message */

                screen.classList.add(
                    "fade"
                );


                await wait(800);


                /*
                 * Continue to Surprise 1.
                 */

                if (
                    typeof Engine !==
                    "undefined" &&
                    typeof Engine.loadScreen ===
                    "function"
                ) {

                    await Engine.loadScreen(
                        "surprise1"
                    );

                }

            };
    }


    console.log(
        "Personal Message Typing Engine Ready"
    );
}