/* =========================================================
   PROJECT MIMI — SURPRISE 8
   THE LITTLE KEEPSAKE — CINEMATIC MEMORY CONSTELLATION
========================================================= */

function initSurprise8(){
    const screen = document.getElementById("surprise8");
    if(!screen || screen.dataset.s8Ready === "1") return;
    screen.dataset.s8Ready = "1";

    const giftPhase = document.getElementById("s8GiftPhase");
    const gift = document.getElementById("s8Gift");
    const memoriesPhase = document.getElementById("s8MemoriesPhase");
    const tokens = [...screen.querySelectorAll(".s8-token")];
    const progressNo = document.getElementById("s8ProgressNo");
    const progressArc = document.getElementById("s8ProgressArc");
    const photos = [...screen.querySelectorAll(".s8-photo")].sort((a,b)=>Number(a.dataset.photo)-Number(b.dataset.photo)).slice(0,4);
    const focus = document.getElementById("s8MemoryFocus");
    const focusImage = document.getElementById("s8FocusImage");
    const focusNo = document.getElementById("s8FocusNo");
    const focusCaption = document.getElementById("s8FocusCaption");
    const focusClose = document.getElementById("s8FocusClose");
    const unlock = document.getElementById("s8Unlock");
    const revealPhase = document.getElementById("s8RevealPhase");
    const next = document.getElementById("s8Next");

    if(!giftPhase || !gift || !memoriesPhase || tokens.length !== 4 || photos.length !== 4 || !focus || !focusImage || !focusClose || !unlock || !revealPhase || !next){
        console.warn("Surprise 8: required elements missing");
        return;
    }

    let busy = false;
    let photoOpen = false;
    const opened = new Set();
    const captions = ["A LITTLE MOMENT","ONE OF THOSE DAYS","THAT SMILE","JUST FOR YOU"];
    const tokenLabels = ["kept moment","little day","that smile","just for you"];
    const pause = ms => new Promise(resolve => setTimeout(resolve, ms));

    const show = el => { if(!el) return; el.classList.add("show"); el.setAttribute("aria-hidden","false"); };
    const hide = el => { if(!el) return; el.classList.remove("show"); el.setAttribute("aria-hidden","true"); };

    function updateProgress(){
        const count = opened.size;
        if(progressNo) progressNo.textContent = String(count);
        if(progressArc){
            const circumference = 2 * Math.PI * 45;
            progressArc.style.strokeDasharray = String(circumference);
            progressArc.style.strokeDashoffset = String(circumference * (1 - count / 4));
        }
    }

    function openGift(){
        if(busy || gift.classList.contains("opened")) return;
        busy = true;
        gift.classList.add("opened");
        setTimeout(async () => {
            hide(giftPhase);
            show(memoriesPhase);
            // The memory phase is interactive as soon as it becomes visible.
            // Do not consume the user's first tap while the gift transition is settling.
            tokens[0]?.focus({preventScroll:true});
            busy = false;
        }, 1250);
    }

    gift.addEventListener("click", openGift);
    gift.addEventListener("keydown", e => {
        if(e.key === "Enter" || e.key === " "){ e.preventDefault(); openGift(); }
    });

    async function openPhoto(index){
        // A token must open on the first deliberate tap. The old global `busy`
        // lock could swallow the first tap during/after the gift transition.
        if(photoOpen || opened.has(index)) return;
        const source = photos[index];
        const token = tokens[index];
        if(!source || !token) return;

        busy = true;
        focusImage.src = source.currentSrc || source.src;
        focusNo.textContent = String(index + 1).padStart(2,"0");
        focusCaption.textContent = captions[index] || "A LITTLE MEMORY";
        token.style.setProperty("--found-image", `url("${source.currentSrc || source.src}")`);
        token.setAttribute("aria-label", `Keepsake ${index + 1} opened — ${tokenLabels[index]}`);
        token.classList.add("found");
        opened.add(index);
        photoOpen = true;
        updateProgress();
        show(focus);
        // Keep the focus animation non-blocking; a tap should never be lost
        // because the reveal is still animating.
        busy = false;
    }

    tokens.forEach((token,index)=>{
        token.addEventListener("click",()=>openPhoto(index));
        token.addEventListener("keydown",e=>{
            if(e.key === "Enter" || e.key === " "){ e.preventDefault(); openPhoto(index); }
        });
    });

    function closePhoto(){
        if(!photoOpen) return;
        photoOpen = false;
        hide(focus);
        if(opened.size === 4){
            setTimeout(()=>{
                unlock.classList.add("show");
                unlock.setAttribute("aria-hidden","false");
            },900);
        }
    }

    focusClose.addEventListener("click",e=>{e.stopPropagation();closePhoto();});
    const backdrop = focus.querySelector(".s8-focus-backdrop");
    if(backdrop) backdrop.addEventListener("click",closePhoto);
    focus.addEventListener("click",e=>{if(e.target === focus) closePhoto();});

    async function openFinalReveal(){
        if(busy || opened.size !== 4) return;
        busy = true;
        hide(unlock);
        hide(memoriesPhase);
        await pause(1250);
        show(revealPhase);
        await pause(6100);
        busy = false;
    }

    unlock.addEventListener("click",openFinalReveal);
    unlock.addEventListener("keydown",e=>{
        if(e.key === "Enter" || e.key === " "){e.preventDefault();openFinalReveal();}
    });

    next.addEventListener("click",async()=>{
        if(next.disabled) return;
        next.disabled = true;
        next.classList.add("pressed");
        revealPhase.classList.add("leaving");
        await pause(1050);
        // Keep the cinematic transition layer alive until the next screen is ready.
        // This prevents the previous blank/dark gap between the memory wall and cake.
        await pause(100);
        if(typeof Engine !== "undefined" && typeof Engine.loadScreen === "function"){
            await Engine.loadScreen("birthdayCake");

            /*
             * S8 owns this handoff. Birthday Cake normally begins with its
             * own 4.2s "for a very special person / wait for it" intro.
             * From S8 that intro is redundant because the memory wall has
             * already supplied the emotional setup.
             *
             * Do not merely remove the intro's class here: birthdayCake.js
             * has its own delayed entrance timer which would add the class
             * again a few seconds later. We therefore pin the intro hidden
             * with an inline !important display rule and reveal the actual
             * cake immediately. This affects only this S8 -> Birthday Cake
             * handoff; the Birthday Cake screen remains unchanged elsewhere.
             */
            const revealCakeImmediately = () => {
                const bcIntro = document.getElementById("bcIntro");
                const bcCake = document.getElementById("bcCake");
                if(!bcIntro || !bcCake) return false;

                bcIntro.classList.remove("show");
                bcIntro.classList.remove("exit");
                bcIntro.setAttribute("aria-hidden","true");
                bcIntro.style.setProperty("display","none","important");

                bcCake.classList.add("show");
                bcCake.setAttribute("aria-hidden","false");
                bcCake.style.setProperty("display","block","important");
                bcCake.style.setProperty("opacity","1","important");
                return true;
            };

            if(!revealCakeImmediately()){
                const handoffTimer = setInterval(()=>{
                    if(revealCakeImmediately()) clearInterval(handoffTimer);
                },16);
                setTimeout(()=>clearInterval(handoffTimer),1500);
            }
        }else{
            console.error("Surprise 8: Engine.loadScreen is unavailable.");
        }
    });

    updateProgress();
    show(giftPhase);
    console.log("Surprise 8 Ready — Keepsake Box → Four Memory Tokens → Memory Wall");
}
