/* PROJECT MIMI — SURPRISE 4 V14 — PREMIUM SCRATCH / CINEMATIC MEMORY FLOW */
(function(){
  'use strict';

  function initSurprise4(){
    const $=s=>document.querySelector(s);
    const intro=$('#s4Intro'),gallery=$('#s4Gallery'),letter=$('#s4Letter');
    const start=$('#s4Start'),image=$('#s4Image'),wrap=$('#s4PhotoWrap'),frame=$('#s4MediaFrame'),stage=$('#s4ImageStage'),canvas=$('#s4Scratch');
    const label=$('#s4ScratchLabel'),flare=document.querySelector('.s4-reveal-flare');
    const note=$('#s4Note'),kicker=$('#s4CaptionKicker'),thought=$('#s4Thought');
    const letterCinema=$('#s4LetterCinema'),openLetter=$('#s4OpenLetter'),letterStage=$('#s4LetterStage'),paper=$('#s4Paper');
    const number=$('#s4Number'),title=$('#s4MemoryTitle'),status=$('#s4Status'),progress=$('#s4ProgressBar');
    const next=$('#s4MemoryNext'),nextLabel=$('#s4NextLabel'),continueBtn=$('#s4Next');
    if(!intro||!gallery||!letter||!start||!image||!wrap||!frame||!stage||!canvas||!next||!continueBtn||!letterCinema||!openLetter||!letterStage||!paper)return;

    const ctx=canvas.getContext('2d',{willReadFrequently:true});
    const memories=[
      {src:'../assets/moment-03.png',alt:'A shared memory together',title:'THE FIRST LOOK',kicker:'THE FIRST LOOK',thought:'That smile. It’s pretty much my favourite view.',zoom:1.055,origin:'50% 48%'},
      {src:'../assets/moment-02.png',alt:'A shared birthday celebration',title:'THAT DAY',kicker:'THAT DAY',thought:'Your happiness will always be my favourite celebration.',zoom:1.055,origin:'50% 46%'},
      {src:'../assets/moment-01.png',alt:'A quiet shared outdoor moment',title:'SOME MOMENTS',kicker:'SOME MOMENTS',thought:'Some moments don’t need a reason, just a place in my heart.',zoom:1.05,origin:'50% 50%'}
    ];

    let current=0,revealed=false,scratching=false,lastPoint=null,painted=0,raf=0,resizeTimer=0,clearTimer=0,zoomTimer=0,zoomRaf=0,sceneBusy=false;

    function show(view){
      [intro,gallery,letter].forEach(v=>{
        const on=v===view;
        v.classList.toggle('is-active',on);
        v.setAttribute('aria-hidden',String(!on));
      });
    }

    function candidates(src){
      const f=src.split('/').pop();
      return [`../assets/${f}`,`/assets/${f}`,`assets/${f}`];
    }

    function loadImageElement(el,src,done){
      let i=0;
      const attempt=()=>{
        if(i>=candidates(src).length){done&&done();return;}
        const url=candidates(src)[i++],pre=new Image();
        pre.onload=()=>{el.src=url;done&&done()};
        pre.onerror=attempt;
        pre.src=url;
      };
      attempt();
    }

    function loadMemory(m){
      loadImageElement(image,m.src,()=>{
        image.alt=m.alt;
        image.style.objectPosition=m.origin;
        stage.style.setProperty('--s4-photo-bg', `url(${m.src})`);
        requestAnimationFrame(sizeCanvas);
      });
    }

    /* The scratch canvas now matches the exact visual photo stage. This removes
       the old mismatch where scratching outside the photo counted as progress. */
    function sizeCanvas(){
      const w=stage.clientWidth,h=stage.clientHeight;
      if(!w||!h)return;
      const dpr=Math.min(window.devicePixelRatio||1,2);
      canvas.width=Math.round(w*dpr);canvas.height=Math.round(h*dpr);
      canvas.style.width=w+'px';canvas.style.height=h+'px';
      ctx.setTransform(dpr,0,0,dpr,0,0);
      paintSurface(w,h);
    }

    function paintSurface(w,h){
      ctx.globalCompositeOperation='source-over';
      ctx.globalAlpha=1;
      ctx.clearRect(0,0,w,h);
      const g=ctx.createLinearGradient(0,0,w,h);
      g.addColorStop(0,'#151922');
      g.addColorStop(.45,'#0b1017');
      g.addColorStop(1,'#17130f');
      ctx.fillStyle=g;ctx.fillRect(0,0,w,h);

      /* restrained tactile grain; still fully opaque */
      ctx.globalAlpha=.075;
      ctx.strokeStyle='#d8bd83';ctx.lineWidth=.45;
      for(let x=-h;x<w+h;x+=24){ctx.beginPath();ctx.moveTo(x,0);ctx.lineTo(x+h,h);ctx.stroke()}
      ctx.globalAlpha=.045;
      for(let i=0;i<Math.floor(w*h/8500);i++){
        const x=Math.random()*w,y=Math.random()*h,r=Math.random()*1.2+.2;
        ctx.fillStyle='#fff3d8';ctx.fillRect(x,y,r,r);
      }
      ctx.globalAlpha=1;
      const sheen=ctx.createRadialGradient(w*.5,h*.45,0,w*.5,h*.45,Math.min(w,h)*.6);
      sheen.addColorStop(0,'rgba(255,239,203,.075)');
      sheen.addColorStop(.5,'rgba(255,239,203,.018)');
      sheen.addColorStop(1,'rgba(0,0,0,0)');
      ctx.fillStyle=sheen;ctx.fillRect(0,0,w,h);
      painted=0;
    }

    function clearPercent(){
      const w=Math.max(1,Math.floor(canvas.width/20)),h=Math.max(1,Math.floor(canvas.height/20));
      const tmp=document.createElement('canvas');tmp.width=w;tmp.height=h;
      const t=tmp.getContext('2d');t.drawImage(canvas,0,0,w,h);
      const d=t.getImageData(0,0,w,h).data;let clear=0,total=w*h;
      for(let i=3;i<d.length;i+=4)if(d[i]<35)clear++;
      return clear/total;
    }

    function scratchAt(clientX,clientY){
      const r=canvas.getBoundingClientRect();
      const x=clientX-r.left,y=clientY-r.top;
      const radius=Math.max(34,Math.min(62,Math.min(r.width,r.height)*.085));
      ctx.save();ctx.globalCompositeOperation='destination-out';
      const erase=(px,py,rr=radius)=>{
        const g=ctx.createRadialGradient(px,py,0,px,py,rr);
        g.addColorStop(0,'rgba(0,0,0,1)');
        g.addColorStop(.72,'rgba(0,0,0,.98)');
        g.addColorStop(1,'rgba(0,0,0,0)');
        ctx.fillStyle=g;ctx.beginPath();ctx.arc(px,py,rr,0,Math.PI*2);ctx.fill();
      };
      erase(x,y);
      if(lastPoint){
        const dx=x-lastPoint.x,dy=y-lastPoint.y,dist=Math.hypot(dx,dy),steps=Math.max(1,Math.ceil(dist/(radius*.22)));
        for(let i=1;i<steps;i++)erase(lastPoint.x+dx*i/steps,lastPoint.y+dy*i/steps,radius*.9);
      }
      ctx.restore();
      lastPoint={x,y};painted++;
      if(painted===1)label.classList.add('is-hidden');
      if(painted%2===0){cancelAnimationFrame(raf);raf=requestAnimationFrame(updateProgress)}
    }

    function updateProgress(){
      const p=clearPercent();
      if(p>.14)status.textContent='KEEP GOING';
      if(p>.34)status.textContent='ALMOST THERE';
      if(p>.42)reveal();
    }

    function stopZoom(){if(zoomRaf)cancelAnimationFrame(zoomRaf);zoomRaf=0;}

    function runCinematicZoom(){
      stopZoom();
      const from=1,to=memories[current].zoom;
      const duration=current===0?5200:(current===1?5000:4800);
      const started=performance.now();
      const ease=t=>1-Math.pow(1-t,3);
      function tick(now){
        const t=Math.min(1,(now-started)/duration);
        image.style.transform=`scale(${(from+(to-from)*ease(t)).toFixed(4)})`;
        if(t<1)zoomRaf=requestAnimationFrame(tick); else zoomRaf=0;
      }
      zoomRaf=requestAnimationFrame(tick);
    }

    function reveal(){
      if(revealed)return;
      revealed=true;scratching=false;lastPoint=null;
      label.classList.add('is-hidden');status.textContent='MEMORY FOUND';
      progress.style.width=((current+1)/3*100)+'%';
      nextLabel.textContent=current===2?'open the letter':'next memory';
      next.classList.remove('is-locked');next.setAttribute('aria-disabled','false');
      wrap.classList.add('is-revealed');flare.classList.add('is-on');
      image.style.transformOrigin=memories[current].origin;
      image.style.transition='none';image.style.transform='scale(1)';

      clearTimeout(zoomTimer);
      zoomTimer=setTimeout(()=>{runCinematicZoom();note.classList.add('revealed');},300);

      clearTimeout(clearTimer);
      clearTimer=setTimeout(()=>{
        ctx.clearRect(0,0,canvas.width,canvas.height);
        canvas.classList.add('is-clearing');canvas.style.pointerEvents='none';
      },620);
      setTimeout(()=>next.classList.add('is-ready'),980);
    }

    function render(){
      revealed=false;scratching=false;lastPoint=null;painted=0;
      cancelAnimationFrame(raf);clearTimeout(clearTimer);clearTimeout(zoomTimer);stopZoom();
      canvas.classList.remove('is-clearing');canvas.style.pointerEvents='auto';
      image.style.transition='none';image.style.transform='scale(1)';image.style.transformOrigin=memories[current].origin;
      flare.classList.remove('is-on');number.textContent=String(current+1).padStart(2,'0');
      progress.style.width=(current/3*100)+'%';note.classList.remove('revealed');wrap.dataset.memory=String(current);
      kicker.textContent=memories[current].kicker;thought.textContent=memories[current].thought;title.textContent=memories[current].title;
      status.textContent='UNCOVER';next.classList.add('is-locked');next.classList.remove('is-ready');next.setAttribute('aria-disabled','true');nextLabel.textContent='uncover to continue';label.classList.remove('is-hidden');
      loadMemory(memories[current]);
    }

    function bindScratch(){
      canvas.addEventListener('pointerdown',e=>{
        if(revealed)return;
        e.preventDefault();
        scratching=true;lastPoint=null;
        try{canvas.setPointerCapture(e.pointerId)}catch(_){}
        scratchAt(e.clientX,e.clientY);
      },{passive:false});
      canvas.addEventListener('pointermove',e=>{
        if(!scratching||revealed)return;
        e.preventDefault();
        scratchAt(e.clientX,e.clientY);
      },{passive:false});
      const up=()=>{if(!scratching)return;scratching=false;lastPoint=null;updateProgress()};
      canvas.addEventListener('pointerup',up,{passive:false});canvas.addEventListener('pointercancel',up,{passive:false});canvas.addEventListener('lostpointercapture',up,{passive:false});
    }

    function resetLetterScene(){
      letterCinema.classList.remove('is-opened');
      letterCinema.classList.remove('is-opening');
      letter.classList.remove('is-opened');openLetter.classList.remove('is-opening');letterStage.classList.remove('is-visible');
      letterStage.setAttribute('aria-hidden','true');letterCinema.setAttribute('aria-hidden','false');openLetter.disabled=false;
      paper.style.animation='none';void paper.offsetHeight;paper.style.animation='';
    }

    function openLetterScene(e){
      e.preventDefault();if(openLetter.disabled)return;openLetter.disabled=true;
      openLetter.classList.add('is-opening');
      letterCinema.classList.add('is-opening');
      window.setTimeout(()=>letterCinema.classList.add('is-opened'),180);
      window.setTimeout(()=>{letterStage.classList.add('is-visible');letterStage.setAttribute('aria-hidden','false');letterCinema.setAttribute('aria-hidden','true')},880);
    }

    function nextMemory(e){
      e.preventDefault();
      if(!revealed||sceneBusy)return;
      sceneBusy=true;
      next.classList.add('is-leaving');
      gallery.classList.add('s4-scene-out');
      window.setTimeout(()=>{
        next.classList.remove('is-leaving');
        gallery.classList.remove('s4-scene-out');
        if(current<2){
          current++;
          render();
          gallery.classList.add('s4-scene-in');
          requestAnimationFrame(()=>window.setTimeout(()=>gallery.classList.remove('s4-scene-in'),30));
        }else{
          show(letter);
          resetLetterScene();
          letter.classList.add('s4-scene-in');
          requestAnimationFrame(()=>window.setTimeout(()=>letter.classList.remove('s4-scene-in'),30));
        }
        sceneBusy=false;
      },420);
    }

    async function goNext(){
      if(continueBtn.dataset.busy==='true')return;continueBtn.dataset.busy='true';
      try{
        if(typeof window.MIMI_GOTO_SCREEN==='function'){window.MIMI_GOTO_SCREEN('surprise5');return}
        if(window.Engine&&typeof window.Engine.loadScreen==='function'){await Promise.resolve(window.Engine.loadScreen('surprise5'));return}
        throw new Error('Navigation API unavailable');
      }catch(e){console.error('S4 continue failed',e);continueBtn.dataset.busy='false'}
    }

    start.addEventListener('click',()=>{current=0;show(gallery);render()});
    next.addEventListener('click',nextMemory);continueBtn.addEventListener('click',goNext);openLetter.addEventListener('click',openLetterScene);
    bindScratch();resetLetterScene();image.addEventListener('load',()=>requestAnimationFrame(sizeCanvas));
    window.addEventListener('resize',()=>{clearTimeout(resizeTimer);resizeTimer=setTimeout(()=>{if(gallery.classList.contains('is-active')&&!revealed)sizeCanvas()},120)});
  }

  window.initSurprise4=initSurprise4;
  if(document.readyState==='loading')document.addEventListener('DOMContentLoaded',initSurprise4,{once:true});else initSurprise4();
})();
