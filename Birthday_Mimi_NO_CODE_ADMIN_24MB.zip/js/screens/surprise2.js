/* PROJECT MIMI — SURPRISE 2 — FINAL CINEMATIC THOUGHT JOURNEY */

function initSurprise2(){

    const intro = document.getElementById("s2Intro");
    const begin = document.getElementById("s2Begin");
    const thought = document.getElementById("s2Thought");
    const text = document.getElementById("s2ThoughtText");
    const index = document.getElementById("s2Index");
    const wrap = document.getElementById("s2Continue");
    const next = document.getElementById("s2Next");

    if(!intro || !begin || !thought || !text || !index){
        console.warn("Surprise 2 elements not found");
        return;
    }

    const thoughts = [
        "Kuch log apni presence se nahi, apne chhote-chhote details se yaad reh jaate hain.",
        "Kisi random din ki ek ordinary si baat bhi kabhi-kabhi memory ban jaati hai — bina permission liye.",
        "Zindagi ke best chapters hamesha dramatic nahi hote. Kabhi ek simple sa moment bhi kaafi hota hai.",
        "Aap jitni jaldi mein life ko samajhne ki koshish karti hain, kabhi-kabhi usse thoda slow karke bas experience bhi kijiye.",
        "Aur jab kabhi peeche mudkar dekhein… toh umeed hai aapko apni journey mein bahut saari achhi cheezein milengi jinke baare mein aaj aapko pata bhi nahi."
    ];

    /* Tight, intentional beats: enough breathing room to feel emotional,
       never long enough to feel like the page is waiting. */
    /* Dedicated reading windows: the text is fully visible before the next
       thought can arrive. Longer thoughts receive more breathing room. */
    const holds = [4800, 5600, 5400, 6200, 7000];

    let started = false;
    let running = false;

    function pauseFor(character){
        if(character === "," || character === ";") return 85;
        if(character === ".") return 150;
        if(character === "?") return 165;
        if(character === "!") return 170;
        if(character === "…") return 220;
        if(character === "—") return 90;
        return 20;
    }

    async function typeThought(value){
        text.textContent = "";

        for(let i = 0; i < value.length; i++){
            text.textContent += value.charAt(i);
            await wait(pauseFor(value.charAt(i)));
        }
    }

    async function showThought(number){

        thought.classList.remove("complete","show","s2-sweep");
        await wait(number === 0 ? 420 : 300);

        const value = thoughts[number];

        index.textContent = String(number + 1).padStart(2,"0");
        text.textContent = "";

        thought.classList.toggle("is-long", value.length > 115);
        thought.classList.add("show");

        /* Let the card settle, then begin the readable text. */
        await wait(300);
        await typeThought(value);

        /* The thought is now fully readable. Give the eye a quiet beat
           before the dedicated reading window begins. */
        thought.classList.add("complete");
        await wait(260);

        /* One restrained paper-light sweep after the thought settles. */
        thought.classList.add("s2-sweep");

        /* Reading pause: the full thought remains on screen long enough
           to read and actually feel it before the next chapter arrives. */
        await wait(holds[number]);
    }

    async function showJourney(){

        for(let i = 0; i < thoughts.length; i++){
            await showThought(i);
        }

        /* Final thought gets a slightly longer emotional breath. */
        await wait(950);

        if(wrap){
            wrap.classList.add("visible");
        }
    }

    begin.onclick = async () => {

        if(started || running) return;

        started = true;
        running = true;
        begin.disabled = true;

        intro.classList.add("hide");

        await wait(620);
        thought.setAttribute("aria-hidden","false");

        await showJourney();

        running = false;
    };

    if(next){
        next.onclick = async () => {

            if(next.disabled) return;

            next.disabled = true;

            const screen = document.getElementById("surprise2");

            if(screen){
                screen.classList.add("fade");
            }

            await wait(720);

            if(typeof Engine !== "undefined" && Engine.loadScreen){
                await Engine.loadScreen("surprise3");
            }
        };
    }

    console.log("Surprise 2 Final Cinematic Ready");
}
