function initboot() {
    let ready = false;
    let opened = false;

    const prompt = document.getElementById("openingPrompt");

    /*
      The button visually appears at 3.1s and finishes its reveal at 4.3s.
      Make it interactive at the same moment.
      The old 7.2s readiness gate caused the first visible tap to be ignored.
    */

    function openJourney(event){
        if(event){
            event.preventDefault();
            event.stopPropagation();
        }

        if(!ready || opened) return;

        opened = true;

        if(prompt){
            prompt.classList.add("is-opening");
            prompt.style.pointerEvents = "none";
            prompt.disabled = true;
        }

        try{
            if(typeof AudioEngine !== "undefined" &&
               typeof AudioEngine.play === "function"){
                AudioEngine.play("page","boot-journey-open");
            }
        }catch(_){}

        const boot = document.getElementById("boot");
        if(!boot) return;

        boot.style.opacity = "0";
        boot.style.transform = "scale(1.025)";
        boot.style.filter = "blur(2px)";

        setTimeout(()=>{
            if(typeof Engine !== "undefined" &&
               typeof Engine.loadScreen === "function"){
                Engine.loadScreen("memoryScan");
            }
        },900);
    }

    if(prompt){
        prompt.style.pointerEvents = "none";
        prompt.disabled = true;

        /* One touch event only. */
        prompt.addEventListener(
            "pointerup",
            openJourney,
            {passive:false}
        );

        prompt.addEventListener("keydown",e=>{
            if(e.key === "Enter" || e.key === " "){
                openJourney(e);
            }
        });
    }

    /*
      promptReveal:
      delay 3.1s + duration 1.2s = 4.3s.
      Unlock immediately after that animation has completed.
    */
    setTimeout(()=>{
        ready = true;

        if(prompt){
            prompt.removeAttribute("aria-hidden");
            prompt.style.pointerEvents = "auto";
            prompt.disabled = false;
        }
    },4350);
}
