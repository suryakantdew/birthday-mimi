/* =========================================================
   PROJECT MIMI — BIRTHDAY CAKE
   PREMIUM CINEMATIC MOMENT — FINAL POLISH
   Replacement file: js/screens/birthdayCake.js
========================================================= */

function initBirthdayCake(){

    const screen = document.getElementById("birthdayCake");
    if(!screen || screen.dataset.bcReady === "1") return;
    screen.dataset.bcReady = "1";

    const intro = document.getElementById("bcIntro");
    const cake = document.getElementById("bcCake");
    const memory = document.getElementById("bcMemory");
    const gift = document.getElementById("bcEnvelope");
    const final = document.getElementById("bcFinal");

    const candles = [...screen.querySelectorAll(".bc-candle")];
    const hint = document.getElementById("bcHint");
    const count = document.getElementById("bcCount");
    const progress = document.getElementById("bcProgressFill");
    const wish = document.getElementById("bcWish");
    const giftButton = document.getElementById("bcEnvelopeButton");
    const continueButton = document.getElementById("bcContinue");
    const lightFirstButton = document.getElementById("bcLightFirst");

    if(!intro || !cake || !memory || !gift || !final ||
       candles.length !== 5 || !giftButton){
        console.warn("Birthday Cake: required elements missing");
        return;
    }

    const pause = ms => new Promise(resolve => setTimeout(resolve, ms));

    let lit = new Set();
    let busy = false;
    let giftOpened = false;

    /* One reusable cinematic light sweep. Created here so HTML stays untouched. */
    let flash = screen.querySelector(".bc-cinematic-flash");
    if(!flash){
        flash = document.createElement("div");
        flash.className = "bc-cinematic-flash";
        flash.setAttribute("aria-hidden","true");
        screen.appendChild(flash);
    }

    function show(el){
        el.setAttribute("aria-hidden","false");
        el.classList.add("show");
    }

    function hide(el){
        el.classList.remove("show");
        el.setAttribute("aria-hidden","true");
    }

    async function move(from,to,waitTime=650){
        hide(from);
        await pause(waitTime);
        show(to);
        /* Destination-specific art direction hooks. */
        if(to === memory){
            screen.classList.remove("bc-enter-memory");
            void screen.offsetWidth;
            screen.classList.add("bc-enter-memory");
            setTimeout(()=>screen.classList.remove("bc-enter-memory"),1800);
        }
        if(to === gift){
            screen.classList.remove("bc-enter-gift");
            void screen.offsetWidth;
            screen.classList.add("bc-enter-gift");
            setTimeout(()=>screen.classList.remove("bc-enter-gift"),1800);
        }
        if(to === final){
            screen.classList.remove("bc-enter-final");
            void screen.offsetWidth;
            screen.classList.add("bc-enter-final");
            cinematicFlash("gift");
            scenePulse("bc-scene-reveal");
            setTimeout(()=>screen.classList.remove("bc-enter-final"),2200);
        }
    }

    function updateProgress(){
        const total = lit.size;
        count.textContent = `${String(total).padStart(2,"0")} / 05`;
        if(progress) progress.style.width = `${total * 20}%`;
    }

    function createBurst(x,y,amount=12,variant="gold"){
        const burst = document.createElement("div");
        burst.className = `bc-burst bc-burst-${variant}`;
        burst.style.left = `${x}px`;
        burst.style.top = `${y}px`;

        for(let i=0;i<amount;i++){
            const p = document.createElement("span");
            const angle = (360 / amount) * i + Math.random()*12;
            const distance = 35 + Math.random()*55;
            p.style.setProperty("--angle",`${angle}deg`);
            p.style.setProperty("--distance",`${distance}px`);
            p.style.animationDelay = `${Math.random()*80}ms`;
            burst.appendChild(p);
        }

        screen.appendChild(burst);
        setTimeout(()=>burst.remove(),950);
    }

    function cinematicFlash(kind="soft"){
        flash.className = `bc-cinematic-flash ${kind}`;
        void flash.offsetWidth;
        flash.classList.add("play");
        setTimeout(()=>flash.classList.remove("play"),1000);
    }

    function scenePulse(kind){
        screen.classList.remove("bc-scene-pulse","bc-scene-gold","bc-scene-reveal");
        void screen.offsetWidth;
        screen.classList.add(kind);
        setTimeout(()=>screen.classList.remove(kind),900);
    }

    async function lightCandle(candle){

        if(busy || candle.classList.contains("lit")) return;

        candle.classList.add("lit");
        lit.add(Number(candle.dataset.candle));
        updateProgress();

        const rect = candle.getBoundingClientRect();
        createBurst(rect.left + rect.width/2, rect.top + 8, 10, "gold");
        scenePulse("bc-scene-pulse");

        screen.classList.remove("bc-touch");
        void screen.offsetWidth;
        screen.classList.add("bc-touch");

        if(lit.size < 5){
            const remaining = 5 - lit.size;
            hint.textContent =
                remaining === 4 ? "one little light..." :
                remaining === 3 ? "keep going..." :
                remaining === 2 ? "it's starting to glow..." :
                "one last little light...";
            return;
        }

        busy = true;
        hint.textContent = "now... this moment is yours";
        progress.style.width = "100%";
        lightFirstButton?.classList.add("completed");

        /* Give the five flames a single, intentional crescendo. */
        cinematicFlash("soft");
        scenePulse("bc-scene-gold");
        await pause(850);

        candles.forEach((c,i)=>{
            c.style.setProperty("--star-delay",`${i*110}ms`);
            c.classList.add("lift");
        });

        /* The flames become a constellation instead of simply disappearing. */
        await pause(850);
        const cakeRect = cake.getBoundingClientRect();
        createBurst(cakeRect.left + cakeRect.width/2, cakeRect.top + cakeRect.height*.27, 22, "star");
        cinematicFlash("wish");

        await pause(650);
        wish.setAttribute("aria-hidden","false");
        wish.classList.add("show");
        scenePulse("bc-scene-reveal");

        await pause(2900);

        wish.classList.remove("show");
        await pause(850);

        await move(cake,memory,900);
        await pause(3900);

        /* A tiny breath before the gift arrives keeps the emotional beat intentional. */
        cinematicFlash("soft");
        await pause(250);
        await move(memory,gift,850);
        busy = false;
    }

    if(lightFirstButton){
        lightFirstButton.addEventListener("click",()=>{
            const next = candles.find(c => !c.classList.contains("lit"));
            if(next) lightCandle(next);
        });
    }

    candles.forEach(candle=>{
        candle.addEventListener("click",()=>lightCandle(candle));

        candle.addEventListener("keydown",e=>{
            if(e.key === "Enter" || e.key === " "){
                e.preventDefault();
                lightCandle(candle);
            }
        });
    });

    giftButton.addEventListener("click",async()=>{
        if(busy || giftOpened) return;

        giftOpened = true;
        busy = true;
        giftButton.classList.add("opening");
        cinematicFlash("gift");

        const rect = giftButton.getBoundingClientRect();
        createBurst(rect.left + rect.width/2, rect.top + rect.height*.35, 18, "star");

        await pause(1350);
        createBurst(rect.left + rect.width/2, rect.top + rect.height*.35, 10, "gold");
        cinematicFlash("wish");
        await pause(420);
        await move(gift,final,820);

        busy = false;
    });

    if(continueButton){
        continueButton.addEventListener("click",async()=>{
            continueButton.disabled = true;
            continueButton.classList.add("pressed");
            cinematicFlash("soft");

            /*
             * Do not guess the next screen here.
             * Engine/router can connect the next completed surprise.
             */
            if(typeof Engine !== "undefined" && typeof Engine.loadScreen === "function"){
                await Engine.loadScreen("finalSurprise");
            } else {
                console.log("Final Surprise route unavailable");
            }
        });
    }

    updateProgress();
    show(intro);

    /* Very slow, premium entrance — shortened slightly so the experience starts sooner. */
    (async()=>{
        await pause(2750);
        intro.classList.add("exit");
        await pause(1250);
        hide(intro);
        show(cake);
        scenePulse("bc-scene-reveal");
    })();

    console.log("Birthday Cake Ready — Final 10/10 Master Polish");
}
