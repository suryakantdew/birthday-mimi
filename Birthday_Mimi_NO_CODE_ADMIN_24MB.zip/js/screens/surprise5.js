/* =========================================================
   PROJECT MIMI — SURPRISE 5
   THE HIDDEN PHOTOGRAPH
   PUZZLE → PHOTO REVEAL → SECRET SPARK → GARDEN GATE
========================================================= */

function initSurprise5(){

    const screen = document.getElementById("surprise5");

    if(!screen || screen.dataset.s5Ready === "1") return;

    /* Keep the global sound control away from S5's bottom CTA/footer. */
    document.body.classList.add("s5-audio-safe");
    const restoreAudioPosition = () => document.body.classList.remove("s5-audio-safe");
    screen.dataset.s5Ready = "1";

    const intro = document.getElementById("s5Intro");
    const begin = document.getElementById("s5Begin");
    const puzzle = document.getElementById("s5Puzzle");
    const board = document.getElementById("s5Board");
    const count = document.getElementById("s5Count");
    const progress = document.getElementById("s5Progress");
    const status = document.getElementById("s5Status");
    const statusDot = document.getElementById("s5StatusDot");
    const movesLabel = document.getElementById("s5Moves");
    const reveal = document.getElementById("s5Reveal");
    const spark = document.getElementById("s5PhotoSpark");
    const hint = document.getElementById("s5PhotoHint");
    const afterPhoto = document.getElementById("s5AfterPhoto");
    const toGate = document.getElementById("s5ToGate");

    if(!intro || !begin || !puzzle || !board || !reveal || !afterPhoto || !toGate){
        console.warn("Surprise 5 elements not found");
        return;
    }

    const total = 16;
    let order = Array.from({length: total}, (_,i) => i);
    let selected = null;
    let locked = false;
    let started = false;
    let completed = false;
    let secretFound = false;
    let moves = 0;

    /* Deterministic scramble so the test is repeatable. */
    const scramble = [5, 0, 13, 8, 3, 11, 6, 15, 1, 14, 9, 4, 12, 7, 2, 10];
    order = [...scramble];

    function isSolved(){
        return order.every((value,index) => value === index);
    }

    function solvedCount(){
        let n = 0;
        order.forEach((value,index) => {
            if(value === index) n++;
        });
        return n;
    }

    function updateProgress(){
        const solved = solvedCount();
        count.textContent = `${String(solved).padStart(2,"0")} / ${total}`;
        if(movesLabel) movesLabel.textContent = `${moves} ${moves === 1 ? "move" : "moves"}`;
        progress.style.width = `${(solved / total) * 100}%`;
    }

    function pieceStyle(pieceIndex){
        const row = Math.floor(pieceIndex / 4);
        const col = pieceIndex % 4;
        return `background-position:${col * 33.3333}% ${row * 33.3333}%;`;
    }

    function renderBoard(){
        board.innerHTML = "";

        order.forEach((pieceIndex, slotIndex) => {
            const piece = document.createElement("button");
            piece.type = "button";
            piece.className = "s5-piece";
            piece.dataset.slot = String(slotIndex);
            piece.dataset.piece = String(pieceIndex);
            piece.style.cssText = pieceStyle(pieceIndex);
            piece.setAttribute("aria-label", `photo piece ${pieceIndex + 1}`);

            if(pieceIndex === slotIndex){
                piece.classList.add("correct");
            }

            piece.addEventListener("click", () => selectPiece(slotIndex));
            board.appendChild(piece);
        });

        updateProgress();
    }

    function selectPiece(slot){
        if(locked || completed) return;

        const piece = board.children[slot];
        if(!piece) return;

        if(selected === null){
            selected = slot;
            piece.classList.add("selected");
            status.textContent = "Choose another piece to swap.";
            statusDot.classList.add("active");
            return;
        }

        if(selected === slot){
            piece.classList.remove("selected");
            selected = null;
            status.textContent = "Choose a piece to begin.";
            statusDot.classList.remove("active");
            return;
        }

        const a = selected;
        const b = slot;
        [order[a], order[b]] = [order[b], order[a]];
        moves++;
        selected = null;

        renderBoard();

        if(order[a] !== a || order[b] !== b){
            const first = board.children[a];
            const second = board.children[b];
            if(first) first.classList.add("just-moved");
            if(second) second.classList.add("just-moved");
            status.textContent = "Keep going…";
        }else{
            status.textContent = "A piece is home.";
            statusDot.classList.add("active");
        }

        if(isSolved()) finishPuzzle();
    }

    async function finishPuzzle(){
        if(completed) return;
        completed = true;
        locked = true;
        status.textContent = "The memory is whole.";
        statusDot.classList.add("active");
        if(movesLabel) movesLabel.textContent = `${moves} ${moves === 1 ? "move" : "moves"}`;

        /* Cinematic payoff: no dead-black gap. The memory resolves, then cross-fades directly into the photograph. */
        puzzle.classList.add("solved-beat");
        board.classList.add("solved");
        await wait(780);

        puzzle.classList.add("memory-complete");
        await wait(430);

        puzzle.classList.add("fade-out");
        await wait(260);

        puzzle.setAttribute("aria-hidden","true");
        reveal.setAttribute("aria-hidden","false");
        reveal.classList.add("show");

        /* Let the photograph breathe before the hidden-detail prompt appears. */
        await wait(2750);
        spark.classList.add("ready");
    }

    begin.onclick = async () => {
        if(started) return;
        started = true;
        begin.disabled = true;
        begin.classList.add("pressed");

        await wait(180);
        intro.classList.add("hide");
        await wait(850);

        puzzle.setAttribute("aria-hidden","false");
        puzzle.classList.add("show");
        renderBoard();
        status.textContent = "Choose a piece to begin.";
    };

    spark.onclick = async () => {
        if(secretFound || !completed) return;
        secretFound = true;
        spark.disabled = true;
        spark.classList.add("collected");
        hint.setAttribute("aria-hidden","false");
        hint.classList.add("show");
        reveal.classList.add("secret-found");

        /* HARD HANDOFF: close the reveal scene before the bridge scene owns the screen.
           This prevents any reveal text/photo/control from ghosting underneath the
           ONE MORE STEP scene, even for a single animation frame. */
        reveal.classList.add("handoff");
        afterPhoto.setAttribute("aria-hidden","false");
        afterPhoto.classList.add("show");
        await wait(90);
        reveal.classList.add("hard-hidden");
        reveal.setAttribute("aria-hidden","true");
        await wait(670);
        reveal.classList.remove("show");
    };

    toGate.onclick = async () => {
        if(toGate.disabled || !secretFound) return;
        toGate.disabled = true;
        toGate.classList.add("pressed");

        afterPhoto.classList.add("leave");
        await wait(900);

        restoreAudioPosition();
        if(typeof Engine !== "undefined" && typeof Engine.loadScreen === "function"){
            await Engine.loadScreen("gardenGate");
        }
    };

    renderBoard();

    console.log("Surprise 5 Ready — Photo Puzzle Experience");
}
