/* ==========================================
   MOVIE INTRO — CINEMATIC CHAPTER OPEN
========================================== */

function initMovieIntro() {

    const button = document.getElementById("movieContinue");
    const intro = document.getElementById("movieIntro");

    if (!button || !intro) return;

    let opened = false;

    async function openJourney(event){

        if(event){
            event.preventDefault();
            event.stopPropagation();
        }

        if(opened || button.disabled) return;

        opened = true;
        button.disabled = true;

        try{
            if(typeof AudioEngine !== "undefined" &&
               typeof AudioEngine.play === "function"){
                AudioEngine.play("tap","movie-intro-continue");
            }
        }catch(_){}

        button.animate(
            [
                {transform:"scale(1)"},
                {transform:"scale(.965)"},
                {transform:"scale(1.015)"},
                {transform:"scale(1)"}
            ],
            {
                duration:320,
                easing:"cubic-bezier(.18,.8,.22,1)"
            }
        );

        await wait(180);

        /*
         * Engine owns the visual handoff. Keep Movie Intro visible
         * until the destination screen has painted.
         */
        try{
            if(typeof AudioEngine !== "undefined" &&
               typeof AudioEngine.play === "function"){
                AudioEngine.play("transition","movie-intro-exit");
            }
        }catch(_){}

        Engine.loadScreen("journey");
    }

    /*
      One pointer path on mobile prevents a single touch from
      producing duplicate navigation.
    */
    button.addEventListener("pointerup",openJourney,{passive:false});

    button.addEventListener("keydown",e=>{
        if(e.key==="Enter" || e.key===" "){
            openJourney(e);
        }
    });
}
