/* =========================================================
   PROJECT MIMI — GARDEN GATE
   CLEAN THEME-MATCHED FLOW
   3 quiet signs → flower → firefly → unlock → open → Wish Garden
========================================================= */
function initGardenGate(){
  const screen=document.getElementById("gardenGate");
  if(!screen || screen.dataset.ggReady==="1") return;
  screen.dataset.ggReady="1";
  const wait=ms=>new Promise(r=>setTimeout(r,ms));

  const intro=screen.querySelector("#ggIntro");
  const phase=screen.querySelector("#ggGate");
  const start=screen.querySelector("#ggStart");
  const gate=screen.querySelector(".gg-gate");
  const doors=[...screen.querySelectorAll(".gg-door")];
  const signs=[...screen.querySelectorAll(".gg-sign")];
  const dots=[...screen.querySelectorAll(".gg-dots i")];
  const seed=screen.querySelector("#ggSeed");
  const firefly=screen.querySelector("#ggFirefly");
  const keyhole=screen.querySelector("#ggKeyhole");
  const hint=screen.querySelector("#ggDragHint");
  const status=screen.querySelector("#ggStatus");
  if(!intro||!phase||!start||!gate||doors.length!==2||signs.length!==3||!seed||!firefly||!keyhole||!hint) return;

  let started=false,found=0,busy=false,unlocked=false,opened=false,dragging=false,startX=0;

  const setStatus=t=>{if(status) status.textContent=t;};
  const updateDots=()=>dots.forEach((d,i)=>d.classList.toggle("found",i<found));
  const lockSigns=()=>signs.forEach(s=>{s.style.pointerEvents="none";s.setAttribute("aria-disabled","true")});

  async function begin(){
    if(started)return;
    started=true;start.disabled=true;
    intro.classList.add("leave");
    await wait(620);
    intro.setAttribute("aria-hidden","true");
    phase.setAttribute("aria-hidden","false");
    phase.classList.add("active");
    setStatus("Notice the little things.");
    await wait(420);
    signs.forEach((s,i)=>setTimeout(()=>s.classList.add("ready"),i*300));
  }
  start.addEventListener("click",begin);

  async function findSign(sign,index){
    if(!started||busy||unlocked||opened||sign.classList.contains("found"))return;
    sign.classList.add("found");found++;updateDots();
    setStatus(found===3?"Something has begun to bloom.":`${found} of 3 quiet signs found`);
    await wait(260);
    if(found!==3)return;
    busy=true;lockSigns();signs.forEach(s=>s.classList.add("complete"));
    await wait(520);
    seed.classList.add("show");seed.setAttribute("aria-hidden","false");
    busy=false;
  }
  signs.forEach((s,i)=>{
    s.addEventListener("click",()=>findSign(s,i));
    s.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();findSign(s,i)}});
  });

  async function bloom(){
    if(busy||found!==3||unlocked||opened||!seed.classList.contains("show"))return;
    busy=true;seed.disabled=true;seed.classList.add("bloom");setStatus("Follow the light.");
    await wait(1050);
    firefly.classList.add("fly");firefly.setAttribute("aria-hidden","false");
    await wait(1900);
    keyhole.classList.add("unlocked");unlocked=true;setStatus("The way is open.");
    await wait(500);
    hint.classList.add("show");hint.setAttribute("aria-hidden","false");busy=false;
  }
  seed.addEventListener("click",bloom);

  function pointerDown(e){
    if(!unlocked||opened)return;
    dragging=true;startX=e.clientX??0;gate.setPointerCapture?.(e.pointerId);
    gate.classList.add("dragging");
  }
  function pointerMove(e){
    if(!dragging||opened)return;
    const x=e.clientX??startX,delta=Math.max(0,Math.min(110,x-startX));
    gate.style.setProperty("--drag",`${delta}px`);
    if(delta>=62)openGate();
  }
  function pointerUp(){
    if(!dragging)return;dragging=false;gate.classList.remove("dragging");
    if(!opened)gate.style.removeProperty("--drag");
  }
  gate.addEventListener("pointerdown",pointerDown);
  gate.addEventListener("pointermove",pointerMove);
  gate.addEventListener("pointerup",pointerUp);
  gate.addEventListener("pointercancel",pointerUp);
  hint.addEventListener("click",openGate);
  gate.addEventListener("click",()=>{if(unlocked&&!opened)openGate()});

  async function openGate(){
    if(opened||!unlocked)return;
    opened=true;dragging=false;gate.style.removeProperty("--drag");
    gate.classList.remove("dragging");gate.classList.add("open");phase.classList.add("garden-opening");
    hint.classList.remove("show");hint.setAttribute("aria-hidden","true");
    setStatus("Welcome to the garden.");
    await wait(2050);
    screen.classList.add("fade-out");
    await wait(780);
    if(typeof Engine!=="undefined"&&typeof Engine.loadScreen==="function") await Engine.loadScreen("wishGarden");
  }

  if(window.location.hash==="#gate-ready")setTimeout(begin,180);
  console.log("Garden Gate Ready — theme matched");
}
