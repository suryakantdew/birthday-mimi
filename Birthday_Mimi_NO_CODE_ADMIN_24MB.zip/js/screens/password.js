async function initPassword() {

    const input = document.getElementById("vaultPassword");
    const button = document.getElementById("unlockButton");
    const message = document.getElementById("vaultMessage");
    const toggle = document.getElementById("togglePassword");
    const stage = document.getElementById("vaultStage");
    const passwordScreen = document.getElementById("password");
    const welcome = document.getElementById("welcomeLayer");

    if(!input || !button) return;

    let busy = false;

    function playSfx(name,key){
        try{
            if(typeof AudioEngine !== "undefined" &&
               typeof AudioEngine.play === "function"){
                AudioEngine.play(name,key);
            }
        }catch(_){}
    }

    function showMessage(text){
        if(!message) return;
        message.textContent=text;
        message.classList.add("show");
    }

    if(toggle){
        toggle.addEventListener("click",()=>{
            const hidden=input.type==="password";
            input.type=hidden?"text":"password";
            toggle.setAttribute("aria-label",hidden?"Hide password":"Show password");
            playSfx("tap","password-visibility");
        });
    }

    function shakeInput(){
        input.animate([
            {transform:"translateX(0)"},
            {transform:"translateX(-7px)"},
            {transform:"translateX(7px)"},
            {transform:"translateX(-5px)"},
            {transform:"translateX(5px)"},
            {transform:"translateX(0)"}
        ],{
            duration:380,
            easing:"cubic-bezier(.36,.07,.19,.97)"
        });
    }

    async function unlock(){

        if(busy) return;
        busy=true;
        button.disabled=true;

        playSfx("tap","vault-submit");

        button.animate([
            {transform:"scale(1)"},
            {transform:"scale(.975)"},
            {transform:"scale(1)"}
        ],{
            duration:220,
            easing:"ease-out"
        });

        await Utils.wait(140);

        if(input.value === Config.get("password")){

            playSfx("unlock","vault-success");

            button.classList.add("unlocked");
            showMessage("The door remembers you... 🌸");

            if(stage){
                stage.classList.add("unlocking");
            }

            await Utils.wait(800);

            if(passwordScreen){
                passwordScreen.classList.add("welcome-transition");
            }

            /* Let the entire vault UI disappear before Welcome takes over. */
            await Utils.wait(690);

            if(welcome){
                welcome.classList.add("is-visible");
                welcome.setAttribute("aria-hidden","false");
            }

            await Utils.wait(1650);

            /*
              Crossfade directly into Movie Intro.
              Do not leave a long fully-black gap between chapters.
            */
            /*
              Keep the same blue/gold atmosphere alive while the next
              screen is mounted. This removes the black flash completely.
            */
            if(passwordScreen){
                passwordScreen.classList.add("chapter-handoff");
            }

            await Utils.wait(220);

            Engine.loadScreen("movieIntro");

        }else{

            playSfx("error","vault-wrong-key");

            shakeInput();

            showMessage("Almost... try once more. 🌸");

            input.value="";
            input.focus();

            button.disabled=false;
            busy=false;
        }
    }

    button.addEventListener("click",unlock);

    input.addEventListener("keydown",e=>{
        if(e.key==="Enter"){
            e.preventDefault();
            unlock();
        }
    });

    /* Small first-focus cue: the secret is waiting for her. */
    setTimeout(()=>{
        if(input && document.activeElement!==input){
            input.animate([
                {boxShadow:"0 0 0 rgba(255,215,120,0)"},
                {boxShadow:"0 0 26px rgba(255,215,120,.12)"},
                {boxShadow:"0 0 0 rgba(255,215,120,0)"}
            ],{
                duration:1500,
                easing:"ease-in-out"
            });
        }
    },2100);
}
