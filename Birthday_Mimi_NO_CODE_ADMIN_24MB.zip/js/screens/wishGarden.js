/* PROJECT MIMI — WISH GARDEN V6 | completely new courtyard composition */
function initWishGarden(){
  const screen=document.getElementById("wishGarden");
  if(!screen||screen.dataset.wgReady==="1") return;
  screen.dataset.wgReady="1";
  const lights=[...screen.querySelectorAll(".wg-light")], bloom=document.getElementById("wgBloom"), stage=document.getElementById("wgWishStage"), input=document.getElementById("wgWishInput"), count=document.getElementById("wgWishCount"), plant=document.getElementById("wgPlantWish"), planting=document.getElementById("wgPlanting"), reply=document.getElementById("wgReply"), replyText=document.getElementById("wgReplyText"), cont=document.getElementById("wgContinue"), progress=document.getElementById("wgProgress"), discovery=document.getElementById("wgDiscoveryLine"), hint=document.getElementById("wgDiscoveryHint"), closeWish=document.getElementById("wgWishClose");
  if(lights.length!==5||!bloom||!stage||!input||!plant||!planting||!reply||!replyText||!cont) return;
  let found=0,busy=false,submitted=false;
  const wait=ms=>new Promise(r=>setTimeout(r,ms));
  const keyboard=(forced=null)=>{
    const vv=window.visualViewport;
    const active=forced===null ? (document.activeElement===input || (!!vv&&vv.height<window.innerHeight*.92)) : forced;
    screen.classList.toggle("wg-keyboard",active);
    if(vv){
      screen.style.setProperty("--wg-visible-vh", `${Math.round(vv.height)}px`);
      screen.style.setProperty("--wg-visible-bottom", `${Math.round(vv.height + vv.offsetTop)}px`);
    }
  };
  input.addEventListener("focus",()=>keyboard(true));
  input.addEventListener("blur",()=>setTimeout(()=>keyboard(false),120));
  window.visualViewport?.addEventListener("resize",()=>keyboard(document.activeElement===input));
  const messages=["the first light noticed you","a second little light is awake","the garden kept another one for you","almost there… one more is hiding","you found them all"];
  lights.forEach((light,i)=>light.addEventListener("click",async()=>{
    if(busy||light.classList.contains("found"))return;
    busy=true;light.classList.add("found");found++;progress.textContent=String(found).padStart(2,"0");discovery.textContent="THE GARDEN IS LISTENING";hint.textContent=messages[Math.min(found,4)];
    light.animate([{transform:"scale(.7)"},{transform:"scale(1.5)"},{transform:"scale(1)"}],{duration:600,easing:"cubic-bezier(.2,.8,.2,1)"});
    await wait(420);busy=false;
    if(found===5)await revealBloom();
  }));
  async function revealBloom(){busy=true;screen.classList.add("wg-bloom-ready");discovery.textContent="A QUIET PLACE HAS OPENED";hint.textContent="touch the centre";await wait(500);bloom.setAttribute("aria-hidden","false");bloom.classList.add("show");await wait(700);busy=false}
  async function openBloom(){if(busy||found<5)return;busy=true;screen.classList.add("wg-bloom-bridge");await wait(260);screen.classList.remove("wg-bloom-ready");bloom.classList.add("open");await wait(620);screen.classList.add("wg-wish-open");stage.setAttribute("aria-hidden","false");stage.classList.add("show");bloom.classList.remove("show","open");bloom.setAttribute("aria-hidden","true");await wait(550);busy=false;setTimeout(()=>{input.focus();keyboard(true)},250)}
  bloom.addEventListener("click",openBloom);bloom.addEventListener("keydown",e=>{if(e.key==="Enter"||e.key===" "){e.preventDefault();openBloom()}});
  closeWish?.addEventListener("click",()=>{if(busy||submitted)return;stage.classList.remove("show");screen.classList.remove("wg-wish-open");stage.setAttribute("aria-hidden","true")});
  input.addEventListener("input",()=>count.textContent=`${input.value.length} / 500`);
  function localReply(wish){return "Aapne jo wish maangi hai na… ✨\n\nmaine use dil mein rakh liya hai.\n\nAapne mujhse maanga hai,\nto use main zaroor poora karunga. 🤍\n\nAap bas wish maangiye, Mimi…\nuse sach karne ki poori koshish meri hogi. 🌙✨\n\nAur jab woh poori hogi,\naapki smile hi meri sabse badi khushi hogi. 🤍"}
  async function typeReply(text){
    replyText.textContent="";
    for(const ch of [...text]){
      replyText.textContent+=ch;
      let delay=24;
      if(ch==="\n") delay=180;
      else if(ch===".") delay=150;
      else if(ch===","||ch==="—") delay=85;
      else if(ch===" ") delay=28;
      else if(/[!?]/.test(ch)) delay=140;
      await wait(delay);
    }
    // Completed text stays exactly where it landed. No second animation.
    replyText.classList.add("is-complete");
  }
  async function submitWish(){if(submitted||busy)return;screen.classList.remove("wg-keyboard");screen.classList.add("wg-wish-bridge");const wish=input.value.trim();if(wish.length<2){input.focus();input.animate([{transform:"translateX(-5px)"},{transform:"translateX(5px)"},{transform:"translateX(0)"}],{duration:260});return}submitted=true;busy=true;plant.disabled=true;input.disabled=true;stage.classList.add("leaving");await wait(360);stage.classList.remove("show","leaving");stage.setAttribute("aria-hidden","true");planting.setAttribute("aria-hidden","false");planting.classList.add("show");await wait(180);screen.classList.remove("wg-wish-bridge");screen.classList.add("wg-rooting-active");let msg="";const endpoint=(window.MIMI_WISH_API||"/api/wish").trim().replace(/\/$/,"");if(endpoint){try{const res=await fetch(endpoint,{method:"POST",headers:{"Content-Type":"application/json"},body:JSON.stringify({wish})});const data=await res.json().catch(()=>({}));if(!res.ok)throw new Error(data.error||"Wish service unavailable");msg=data.reply||localReply(wish)}catch(e){console.error(e);msg=localReply(wish)}}else msg=localReply(wish);await wait(2200);screen.classList.add("wg-reply-bridge");planting.classList.add("leaving");await wait(520);planting.classList.remove("show","leaving");planting.setAttribute("aria-hidden","true");reply.setAttribute("aria-hidden","false");reply.classList.add("show");await wait(1250);await typeReply(msg);screen.classList.remove("wg-rooting-active","wg-reply-bridge");screen.classList.add("wg-reply-finished","wg-final-hold");reply.classList.add("cinematic-finish");await wait(900);busy=false}
  plant.addEventListener("click",submitWish);
  cont.addEventListener("click",async()=>{if(busy)return;cont.disabled=true;screen.classList.add("fade");await wait(650);if(typeof Engine!=="undefined"&&typeof Engine.loadScreen==="function")await Engine.loadScreen("surprise8")});
  console.log("Wish Garden Final Cinematic Ready");
}
