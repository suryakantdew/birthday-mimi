/* PROJECT MIMI — SURPRISE 3: WINDOW 03 / GLASS REVEAL */
async function initSurprise3(){
  const intro=document.getElementById("s3WindowIntro"),look=document.getElementById("s3Look");
  const view=document.getElementById("s3Window"),writing=document.getElementById("s3GlassWriting");
  const glow=document.getElementById("s3WritingGlow"),glassText=document.getElementById("s3GlassText");
  const count=document.getElementById("s3WindowCount"),prompt=document.getElementById("s3WindowPrompt");
  const final=document.getElementById("s3WindowFinal"),next=document.getElementById("s3Next"),exit=document.getElementById("s3CinematicExit");
  const hotspots=view?view.querySelectorAll(".s3-window-hotspot"):[];
  if(!intro||!look||!view||!writing||!final)return;

  const notes=[
    "Kuch moments bina reason ke bhi yaad reh jaate hain.",
    "Kuch hasiiyan moment se zyada, ek feeling ban jaati hain.",
    "Kuch ordinary days baad mein special lagte hain.",
    "Kisi ki presence kab important hui… pata hi nahi chalta.",
    "Aur kuch log quietly apni jagah bana lete hain."
  ];
  let found=new Set(),busy=false;

  const wait=ms=>new Promise(r=>setTimeout(r,ms));
  function update(){count.textContent="";prompt.textContent=found.size<5?"just look outside":"the view is almost complete"}

  async function writeOnGlass(value){
    glassText.textContent="";
    for(let i=0;i<value.length;i++){
      glassText.textContent+=value[i];
      await wait(value[i]==="."?95:value[i]==="…"?170:23);
    }
  }

  async function reveal(h){
    if(busy||found.has(h.dataset.note))return;
    busy=true;
    const i=Number(h.dataset.note);
    found.add(h.dataset.note);h.classList.add("found");update();
    glow.classList.remove("show");void glow.offsetWidth;glow.classList.add("show");
    await wait(180);
    writing.classList.add("show");
    await writeOnGlass(notes[i]);
    await wait(Math.max(2900,Math.min(3900,2900+notes[i].length*10)));
    writing.classList.remove("show");
    await wait(850);
    if(found.size===5){
      prompt.textContent="the view is complete";
      view.classList.add("complete");
      await wait(500);
      if(exit){exit.classList.add("active");}
      await wait(1450);
      view.classList.remove("show");
      await wait(650);
      if(exit){exit.classList.remove("active");}
      final.classList.add("show");busy=false;return;
    }
    busy=false;
  }

  hotspots.forEach(h=>h.addEventListener("click",()=>reveal(h)));

  look.onclick=async()=>{
    look.disabled=true;
    intro.classList.add("hide");
    await wait(760);
    view.classList.add("show");
    view.setAttribute("aria-hidden","false");
    update();
  };

  next.onclick=async()=>{
    next.disabled=true;
    await wait(320);
    await Engine.loadScreen("surprise4");
  };
  update();
}
