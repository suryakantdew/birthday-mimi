/* ==========================================
   JOURNEY — CHAPTER ONE / CINEMATIC ENTRY
========================================== */

function initJourney() {

    const button = document.getElementById("journeyStart");
    const journey = document.getElementById("journey");

    if (!button || !journey) return;

    let opened = false;

    function playSfx(name,key){
        try{
            if(typeof AudioEngine !== "undefined" &&
               typeof AudioEngine.play === "function"){
                AudioEngine.play(name,key);
            }
        }catch(_){}
    }

    async function openJourney(event){

        if(event){
            event.preventDefault();
            event.stopPropagation();
        }

        if(opened || button.disabled) return;

        opened = true;
        button.disabled = true;

        playSfx("tap","journey-begin");

        button.animate(
            [
                {transform:"scale(1)"},
                {transform:"scale(.955)"},
                {transform:"scale(1.018)"},
                {transform:"scale(1)"}
            ],
            {
                duration:330,
                easing:"cubic-bezier(.18,.8,.22,1)"
            }
        );

        await wait(170);

        playSfx("transition","journey-exit");

        journey.classList.add("is-opening");

        /* Keep Journey visible until Memory 1 is mounted. */
        await wait(210);

        Engine.loadScreen("memory1");
    }

    /* One pointer path prevents duplicate mobile activation. */
    button.addEventListener("pointerup",openJourney,{passive:false});

    button.addEventListener("keydown",e=>{
        if(e.key==="Enter" || e.key===" "){
            openJourney(e);
        }
    });
}

function wait(ms){
    return new Promise(resolve=>setTimeout(resolve,ms));
}
