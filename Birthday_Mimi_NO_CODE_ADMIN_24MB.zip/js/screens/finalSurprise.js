/* =========================================================
   FINAL SURPRISE — PREMIUM LETTER REVEAL
========================================================= */

function initFinalSurprise(){

    const screen = document.getElementById("finalSurprise");
    if(!screen || screen.dataset.fsReady === "1") return;
    screen.dataset.fsReady = "1";

    const opening = document.getElementById("fsOpening");
    const discovery = document.getElementById("fsDiscovery");
    const reveal = document.getElementById("fsReveal");

    const begin = document.getElementById("fsBegin");
    const light = document.getElementById("fsLight");
    const hint = document.getElementById("fsHint");
    const hintText = document.getElementById("fsHintText");
    const finish = document.getElementById("fsFinish");

    if(!opening || !discovery || !reveal || !begin || !light){
        console.warn("Final Surprise: required elements missing");
        return;
    }

    const wait = ms => new Promise(resolve => setTimeout(resolve,ms));

    let taps = 0;
    let locked = false;

    function show(el){
        el.classList.add("show");
        el.setAttribute("aria-hidden","false");
    }

    function hide(el){
        el.classList.remove("show");
        el.setAttribute("aria-hidden","true");
    }

    async function beginReveal(){
        if(locked) return;
        locked = true;
        screen.classList.add("fs-opened");

        hide(opening);
        await wait(900);
        show(discovery);

        locked = false;
    }

    async function touchLight(){
        if(locked) return;
        locked = true;

        taps++;

        light.style.transform = "scale(1.16)";
        await wait(240);
        light.style.transform = "";

        if(taps < 3){
            hint.textContent = String(taps + 1).padStart(2,"0") + " / 03";

            hintText.textContent =
                taps === 1
                    ? "ek baar aur..."
                    : "bas ek baar aur...";

            screen.classList.remove("fs-tap-" + (taps - 1));
            screen.classList.add("fs-tap-" + taps);

            await wait(650);
            locked = false;
            return;
        }

        /* Third touch: cinematic climax -> bloom -> letter reveal. */
        hintText.textContent = "";
        hint.textContent = "✦";
        discovery.classList.add("fs-climax");
        screen.classList.add("fs-tap-3");

        await wait(850);
        hide(discovery);
        await wait(420);
        show(reveal);
        discovery.classList.remove("fs-climax");

        locked = false;
    }

    begin.addEventListener("click",beginReveal);
    light.addEventListener("click",touchLight);

    if(finish){
        finish.addEventListener("click",async ()=>{
            if(finish.disabled) return;
            finish.disabled = true;
            finish.classList.add("pressed");
            await wait(650);

            if(typeof Engine !== "undefined" && typeof Engine.loadScreen === "function"){
                await Engine.loadScreen("emotionalEnding");
                if(typeof initEmotionalEnding === "function"){
                    initEmotionalEnding();
                }
            }else{
                console.warn("Final Surprise: Engine unavailable for Emotional Ending");
            }
        });
    }

    /* Keyboard accessibility */
    [begin,light].forEach(button=>{
        button.addEventListener("keydown",event=>{
            if(event.key === "Enter" || event.key === " "){
                event.preventDefault();
                button.click();
            }
        });
    });

    show(opening);

    console.log("Final Surprise Ready — Premium Letter Reveal");
}


/* =========================================================
   EMOTIONAL ENDING — FINAL CINEMATIC OPEN-ENDED REVEAL
========================================================= */
function initEmotionalEnding(){
  const root=document.getElementById("emotionalEnding");
  if(!root || root.dataset.ceReady==="1") return;
  root.dataset.ceReady="1";

  const s1=root.querySelector("#ceScene1");
  const s2=root.querySelector("#ceScene2");
  const s3=root.querySelector("#ceScene3");
  const s4=root.querySelector("#ceScene4");
  const reveal=root.querySelector("#ceReveal");
  const letter=root.querySelector("#ceLetter");
  const cont=root.querySelector("#ceContinue");
  const replay=root.querySelector("#ceReplay");
  const reply=root.querySelector("#ceReply");
  const replyPanel=root.querySelector("#ceReplyPanel");
  const replyClose=root.querySelector("#ceReplyClose");
  const replyInput=root.querySelector("#ceReplyInput");
  const replySend=root.querySelector("#ceReplySend");
  const replyStatus=root.querySelector("#ceReplyStatus");
  const replyCount=root.querySelector("#ceReplyCount");
  const wait=ms=>new Promise(r=>setTimeout(r,ms));

  const scenes=[s1,s2,s3,s4];
  let transitioning=false;

  function show(scene){
    scenes.forEach(x=>{
      x.classList.remove("active");
      x.setAttribute("aria-hidden","true");
    });
    requestAnimationFrame(()=>{
      requestAnimationFrame(()=>{
        scene.classList.add("active");
        scene.setAttribute("aria-hidden","false");
      });
    });
  }

  async function move(next,delay,button){
    if(transitioning) return;
    transitioning=true;
    if(button) button.disabled=true;
    await wait(delay);
    show(next);
    await wait(1250);
    transitioning=false;
  }

  /* Mobile-safe single-tap navigation: pointerup fires reliably on touch devices. */
  function bindSingleTap(button, handler){
    if(!button) return;
    let lastPointer=0;
    button.addEventListener("pointerup", event=>{
      if(event.pointerType === "mouse" && event.button !== 0) return;
      const now=Date.now();
      if(now-lastPointer < 350) return;
      lastPointer=now;
      event.preventDefault();
      handler();
    });
  }

  bindSingleTap(reveal,()=>move(s2,180,reveal));
  bindSingleTap(letter,()=>move(s3,180,letter));
  bindSingleTap(cont,()=>move(s4,180,cont));

  function openReply(){
    if(!replyPanel) return;
    replyPanel.classList.add("open");
    replyPanel.setAttribute("aria-hidden","false");
    document.body.classList.add("ce-reply-open");
    replyStatus && (replyStatus.textContent="");
    setTimeout(()=>replyInput?.focus(),220);
  }

  function closeReply(){
    if(!replyPanel) return;
    replyPanel.classList.remove("open");
    replyPanel.setAttribute("aria-hidden","true");
    document.body.classList.remove("ce-reply-open");
  }

  function updateReplyCount(){
    if(replyCount && replyInput) replyCount.textContent=`${replyInput.value.length} / 500`;
  }

  async function sendReply(){
    if(!replyInput || !replySend) return;
    const message=replyInput.value.trim();
    if(message.length<2){
      replyStatus.textContent="Thoda sa message likh dijiye…";
      replyInput.focus();
      replyInput.animate([{transform:"translateX(-4px)"},{transform:"translateX(4px)"},{transform:"translateX(0)"}],{duration:220});
      return;
    }

    replySend.disabled=true;
    replyStatus.textContent="Reply ready ho raha hai…";

    const whatsappNumber="919907603598";
    const whatsappText=encodeURIComponent(message);
    const whatsappUrl=`https://wa.me/${whatsappNumber}?text=${whatsappText}`;
    try{
      replyStatus.textContent="WhatsApp khul raha hai… ❤️";
      window.location.href=whatsappUrl;
      setTimeout(()=>{
        replySend.disabled=false;
        if(document.visibilityState==="visible") replyStatus.textContent="WhatsApp open nahi hua? Reply copy karke WhatsApp par paste kar sakti hain.";
      },1400);
    }catch(err){
      try{
        await navigator.clipboard.writeText(message);
        replyStatus.textContent="WhatsApp open nahi hua — reply copy ho gaya ❤️";
      }catch(_){
        replyStatus.textContent="WhatsApp open nahi hua — message select karke copy kijiye.";
      }
      replySend.disabled=false;
    }
  }

  reply?.addEventListener("click",openReply);
  replyClose?.addEventListener("click",closeReply);
  replyPanel?.querySelector("[data-ce-reply-close]")?.addEventListener("click",closeReply);
  replyInput?.addEventListener("input",updateReplyCount);
  replySend?.addEventListener("click",sendReply);

  replay?.addEventListener("click",async()=>{
    if(transitioning) return;
    replay.disabled=true;
    replay.classList.add("pressed");
    await wait(520);
    if(typeof Engine!=="undefined" && typeof Engine.loadScreen==="function"){
      await Engine.loadScreen("boot");
    }else{
      window.location.reload();
    }
  });

  /* Keyboard accessibility */
  [reveal,letter,cont,replay,reply,replyClose,replySend].filter(Boolean).forEach(button=>{
    button.addEventListener("keydown",event=>{
      if(event.key==="Enter" || event.key===" "){
        event.preventDefault();
        button.click();
      }
    });
  });

  document.addEventListener("keydown",event=>{
    if(event.key==="Escape" && replyPanel?.classList.contains("open")) closeReply();
  });

  updateReplyCount();
  show(s1);
  console.log("Emotional Ending Ready — Reply + Final Cinematic Open Loop");
}