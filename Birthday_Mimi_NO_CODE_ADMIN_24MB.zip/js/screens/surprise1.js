/* ==========================================
   SURPRISE 1 — INITIALIZATION
========================================== */

async function initSurprise1() {

    const intro = document.getElementById("s1Intro");
    const open = document.getElementById("s1Open");
    const env = document.getElementById("s1Envelope");
    const next = document.getElementById("s1Next");


    /* ==========================================
       SAFETY CHECK
    ========================================== */

    if (!intro || !open || !env) {
        return;
    }


    /* ==========================================
       STATE
    ========================================== */

    let done = false;


    /* ==========================================
       OPEN SURPRISE 1
    ========================================== */

    open.onclick = async () => {

        if (done) {
            return;
        }

        done = true;

        open.disabled = true;


        /* Button press animation */

        open.style.transform = "scale(.96)";

        await wait(120);

        open.style.transform = "scale(1)";


        /* Hide intro */

        intro.classList.add("hidden");

        await wait(560);


        /* Open envelope */

        env.classList.add("open");

        env.setAttribute(
            "aria-hidden",
            "false"
        );

        await wait(2500);


        /* Show next button */

        if (next) {
            next.classList.add("visible");
            next.style.pointerEvents = "auto";
        }
    };


    /* ==========================================
       NEXT BUTTON — SURPRISE 2
    ========================================== */

    if (next) {

        next.onclick = async () => {

            if (next.disabled) {
                return;
            }

            next.disabled = true;


            /* Button press animation.
               Use a class so the CSS centering transform
               (translateX(-50%)) is never overwritten. */

            next.classList.add("pressed");

            await wait(120);

            next.classList.remove("pressed");


            /* Fade out Surprise 1 */

            const screen =
                document.getElementById("surprise1");

            if (screen) {
                screen.classList.add("fade");
            }

            await wait(800);


            /* Load Surprise 2 */

            await Engine.loadScreen("surprise2");
        };
    }

}