/* Applies saved no-code settings whenever a screen is dynamically mounted. */
(function(){
 function apply(){try{const root=document.getElementById('screenContainer')||document;window.MimiRuntime?.apply(root);const c=window.MimiConfig||{};const controls=c.controls||{};const map={surprise1:'showSurprise1',surprise2:'showSurprise2',surprise3:'showSurprise3',surprise4:'showSurprise4',surprise5:'showSurprise5',gardenGate:'showGardenGate',wishGarden:'showWishGarden',surprise8:'showSurprise8',birthdayCake:'showBirthdayCake',finalSurprise:'showFinalSurprise',emotionalEnding:'showEmotionalEnding'};Object.entries(map).forEach(([id,key])=>{const el=root.querySelector('#'+id);if(el)el.style.display=controls[key]===false?'none':'';});}catch(e){console.warn(e)}}
 new MutationObserver(()=>setTimeout(apply,30)).observe(document.body,{childList:true,subtree:true});
 document.addEventListener('DOMContentLoaded',apply);
})();