/* =========================================================
   PROJECT MIMI — CINEMATIC AUDIO DIRECTOR V7
   Reliable WebAudio-only SFX.
   - No external audio dependency for playback
   - One persistent AudioContext
   - Gesture-safe resume
   - Exact actions + one-shot animations
   - No generic/random click sound
========================================================= */
(function(){
"use strict";

const STORE_MUTE="MIMI_AUDIO_MUTED_V7";
const STORE_VOLUME="MIMI_AUDIO_VOLUME_V7";

let muted=false;
let volume=.72;
let ctx=null;
let readyPromise=null;
let unlocked=false;
let lastKey="";
let lastAt=0;

try{
  muted=localStorage.getItem(STORE_MUTE)==="1";
  const v=Number(localStorage.getItem(STORE_VOLUME));
  if(Number.isFinite(v)&&v>=0&&v<=1) volume=v;
}catch(_){}

function ensureContext(){
  if(ctx) return ctx;
  const AC=window.AudioContext||window.webkitAudioContext;
  if(!AC) return null;
  try{
    ctx=new AC();
    return ctx;
  }catch(err){
    console.warn("[MIMI AUDIO] AudioContext unavailable",err);
    return null;
  }
}

/*
 * Resume is deliberately initiated from the real pointer/click.
 * The promise is stored so every sound waits for the same unlock.
 */
function unlock(){
  const ac=ensureContext();
  if(!ac) return Promise.resolve(false);

  if(ac.state==="running"){
    unlocked=true;

    /* The BGM is already running after the first interaction.
       NEVER restart it just because another SFX interaction occurred. */
    if(!muted && !musicSource){
      startMusic();
    }

    return Promise.resolve(true);
  }

  if(!readyPromise){
    readyPromise=ac.resume()
      .then(()=>{
        unlocked=ac.state==="running";
        if(unlocked && !muted) startMusic();
        return unlocked;
      })
      .catch(()=>{
        readyPromise=null;
        return false;
      });
  }
  return readyPromise;
}

let sfxBus=null;

function master(){
  const ac=ensureContext();
  if(!ac) return null;

  if(!sfxBus){
    sfxBus=ac.createGain();
    sfxBus.gain.value=volume;
    sfxBus.connect(ac.destination);
  }else{
    sfxBus.gain.setValueAtTime(volume,ac.currentTime);
  }

  return sfxBus;
}

function tone(freq,duration,type="sine",gain=.055,when=0,detune=0){
  const ac=ensureContext();
  if(!ac) return;

  const t=ac.currentTime+when;
  const osc=ac.createOscillator();
  const g=ac.createGain();

  osc.type=type;
  osc.frequency.setValueAtTime(freq,t);
  if(detune) osc.detune.setValueAtTime(detune,t);

  g.gain.setValueAtTime(.0001,t);
  g.gain.exponentialRampToValueAtTime(Math.max(.0002,gain),t+.012);
  g.gain.exponentialRampToValueAtTime(.0001,t+duration);

  osc.connect(g);
  g.connect(ac.destination);
  osc.start(t);
  osc.stop(t+duration+.025);
}

function sweep(f1,f2,duration=.35,gain=.045,when=0){
  const ac=ensureContext();
  if(!ac) return;

  const t=ac.currentTime+when;
  const osc=ac.createOscillator();
  const g=ac.createGain();

  osc.type="sine";
  osc.frequency.setValueAtTime(f1,t);
  osc.frequency.exponentialRampToValueAtTime(f2,t+duration);

  g.gain.setValueAtTime(.0001,t);
  g.gain.exponentialRampToValueAtTime(gain,t+.012);
  g.gain.exponentialRampToValueAtTime(.0001,t+duration);

  osc.connect(g);
  g.connect(ac.destination);
  osc.start(t);
  osc.stop(t+duration+.025);
}

function playUnlocked(name){
  if(muted) return;

  const ac=ensureContext();
  if(!ac || ac.state!=="running") return;

  switch(name){

    case "tap":
      tone(620,.075,"sine",.035);
      break;

    case "page":
      sweep(260,520,.24,.028);
      tone(780,.20,"sine",.018,.12);
      break;

    case "reveal":
      tone(392,.26,"sine",.030);
      tone(523,.32,"sine",.030,.08);
      tone(659,.38,"sine",.026,.17);
      tone(988,.52,"sine",.018,.28);
      break;

    case "memory":
      tone(587,.18,"sine",.032);
      tone(740,.23,"sine",.026,.065);
      break;

    case "choice":
      tone(440,.13,"sine",.028);
      tone(554,.18,"sine",.025,.055);
      break;

    case "bloom":
      tone(392,.20,"sine",.026);
      tone(523,.24,"sine",.030,.075);
      tone(784,.34,"sine",.025,.15);
      tone(1047,.42,"sine",.018,.25);
      break;

    case "plant":
      sweep(330,523,.42,.030);
      tone(659,.28,"sine",.020,.28);
      break;

    case "gift":
      tone(392,.18,"sine",.026);
      tone(523,.23,"sine",.028,.065);
      tone(659,.28,"sine",.026,.13);
      tone(880,.42,"sine",.020,.22);
      break;

    case "candle":
      tone(523,.22,"sine",.025);
      tone(659,.28,"sine",.028,.10);
      tone(784,.36,"sine",.020,.20);
      break;

    case "correct":
      tone(523,.15,"sine",.030);
      tone(659,.19,"sine",.032,.07);
      tone(784,.27,"sine",.028,.14);
      break;

    case "wrong":
      sweep(250,145,.20,.040);
      break;

    case "unlock":
      tone(392,.22,"sine",.025);
      tone(523,.28,"sine",.030,.08);
      tone(659,.34,"sine",.030,.17);
      tone(1047,.60,"sine",.022,.29);
      break;

    case "emotional":
      tone(330,.35,"sine",.020);
      tone(392,.42,"sine",.023,.14);
      tone(523,.50,"sine",.026,.30);
      tone(659,.68,"sine",.020,.48);
      break;

    case "transition":
      sweep(220,440,.22,.020);
      break;

    default:
      return;
  }
}

function play(name,key){
  if(muted) return;
  const now=Date.now();

  /* Prevent pointerdown + click duplicate and animation double-fire. */
  if(key && key===lastKey && now-lastAt<420) return;
  lastKey=key||name;
  lastAt=now;

  const promise=unlock();

  /*
   * If already running, play immediately in the gesture.
   * Otherwise resume first, then play on the unlocked context.
   */
  if(ctx && ctx.state==="running"){
    playUnlocked(name);
  }else{
    promise.then(ok=>{
      if(ok) playUnlocked(name);
    });
  }
}


/* ---------------------------------------------------------
   CINEMATIC AMBIENT MUSIC
   Starts only after the user's first real interaction.
   Very low-volume evolving pad; no autoplay.
--------------------------------------------------------- */
let musicStarted=false;


/* ---------------------------------------------------------
   SCENE-BASED CINEMATIC SCORE
   Every website scene has its own musical mood. The score is
   synthesized with Web Audio, so there are no external music
   files, autoplay downloads, or missing MP3 dependencies.
--------------------------------------------------------- */

const MUSIC_ROOT=new URL("../../assets/audio/music/",document.baseURI).href;

const SCENE_TRACKS={
  boot:"mystery_cinematic.mp3",
  memoryScan:"mystery_cinematic.mp3",
  password:"mystery_cinematic.mp3",
  movieIntro:"mystery_cinematic.mp3",
  journey:"warm_friendship.mp3",
  memory1:"memory_nostalgia.mp3",
  memory2:"memory_nostalgia.mp3",
  memory3:"memory_nostalgia.mp3",
  personalMessage:"deep_emotional.mp3",
  surprise1:"magical_wonder.mp3",
  surprise2:"mystery_cinematic.mp3",
  surprise3:"magical_wonder.mp3",
  surprise4:"magical_wonder.mp3",
  surprise5:"magical_wonder.mp3",
  gardenGate:"magical_wonder.mp3",
  wishGarden:"warm_friendship.mp3",
  surprise8:"memory_nostalgia.mp3",
  birthdayCake:"birthday.mp3",
  finalSurprise:"deep_emotional.mp3",
  emotionalEnding:"deep_emotional.mp3"
};

let musicScene="boot";
let pendingScene="boot";
let musicBuffers={};
let musicLoadPromises={};
let musicSource=null;
let musicBus=null;
let musicReady=false;

function sceneTrack(scene){
  return SCENE_TRACKS[scene] || SCENE_TRACKS.journey;
}

async function loadMusicTrack(file){
  if(musicBuffers[file]) return musicBuffers[file];
  if(musicLoadPromises[file]) return musicLoadPromises[file];

  const ac=ensureContext();
  if(!ac) return null;

  const promise=fetch(MUSIC_ROOT+file,{cache:"force-cache"})
    .then(r=>{
      if(!r.ok) throw new Error("Music HTTP "+r.status+" for "+file);
      return r.arrayBuffer();
    })
    .then(buf=>ac.decodeAudioData(buf))
    .then(decoded=>{
      musicBuffers[file]=decoded;
      console.log("[MIMI MUSIC] Loaded",file);
      return decoded;
    })
    .catch(err=>{
      console.error("[MIMI MUSIC] Failed to load",MUSIC_ROOT+file,err);
      delete musicLoadPromises[file];
      return null;
    });

  musicLoadPromises[file]=promise;
  return promise;
}

function stopSceneMusic(fade=.7){
  const ac=ctx;
  if(!ac) return;

  const now=ac.currentTime;

  if(musicBus){
    try{
      musicBus.gain.cancelScheduledValues(now);
      musicBus.gain.setTargetAtTime(.0001,now,Math.max(.04,fade/3));
    }catch(_){}
  }

  const oldSource=musicSource;
  musicSource=null;

  if(oldSource){
    try{oldSource.stop(now+fade+.05);}catch(_){}
    try{oldSource.disconnect();}catch(_){}
  }

  if(musicBus){
    const oldBus=musicBus;
    musicBus=null;
    setTimeout(()=>{
      try{oldBus.disconnect();}catch(_){}
    },Math.max(150,fade*1000+100));
  }
}

async function startSceneMusic(sceneName,fade=.9){
  if(muted || !unlocked) return false;

  const ac=ensureContext();
  if(!ac || ac.state!=="running") return false;

  const file=sceneTrack(sceneName);
  const buffer=await loadMusicTrack(file);

  if(!buffer || muted || !unlocked || musicScene!==sceneName){
    return false;
  }

  stopSceneMusic(fade);

  const now=ac.currentTime;
  /* Dedicated background-music bus.
     SFX use a separate sfxBus, so a tap/reveal/candle sound
     never pauses, restarts, ducks, or replaces the BGM. */
  const bus=ac.createGain();

  /* Background music remains continuous underneath SFX. */
  bus.gain.setValueAtTime(.0001,now);
  bus.gain.exponentialRampToValueAtTime(
    Math.max(.035,Math.min(.14,volume*.16)),
    now+fade
  );
  bus.connect(ac.destination);

  const source=ac.createBufferSource();
  source.buffer=buffer;
  source.loop=true;
  source.connect(bus);
  source.start(now);

  musicBus=bus;
  musicSource=source;
  musicReady=true;

  console.log("[MIMI MUSIC] PLAY",sceneName,"→",file);
  return true;
}

function setScene(sceneName){
  pendingScene=sceneName||"journey";

  if(musicScene===pendingScene && musicSource){
    console.log("[MIMI MUSIC SCENE] CONTINUE",musicScene);
    return;
  }

  musicScene=pendingScene;

  console.log("[MIMI MUSIC SCENE]",musicScene);

  if(unlocked && !muted){
    startSceneMusic(musicScene,.9);
  }
}

function stopMusic(){
  stopSceneMusic(.25);
  musicStarted=false;
}

function startMusic(){
  if(muted) return false;

  const ac=ensureContext();
  if(!ac) return false;

  if(ac.state==="suspended"){
    ac.resume().catch(()=>{});
  }

  if(ac.state!=="running") return false;

  musicStarted=true;
  unlocked=true;

  /* Already playing = leave it completely untouched.
     This is what keeps BGM continuous under every SFX. */
  if(musicSource){
    return true;
  }

  startSceneMusic(musicScene||pendingScene||"boot",.8);
  return true;
}

function setMuted(v){
  muted=!!v;
  try{localStorage.setItem(STORE_MUTE,muted?"1":"0")}catch(_){}

  if(muted){
    stopMusic();
  }else if(unlocked){
    startMusic();
  }

  updateControl();
}
function setVolume(v){
  volume=Math.max(0,Math.min(1,Number(v)||0));
  try{localStorage.setItem(STORE_VOLUME,String(volume))}catch(_){}
}
function updateControl(){
  const b=document.getElementById("mimiAudioControl");
  if(!b)return;
  b.classList.toggle("muted",muted);
  b.setAttribute("aria-label",muted?"Turn sound on":"Turn sound off");
}

/* ---------------------------------------------------------
   Exact action map.
--------------------------------------------------------- */
const ACTIONS=[
  ["#togglePassword","tap"],
  ["#unlockButton","unlock"],
  ["#movieContinue","page"],
  ["#journeyStart","page"],
  ["#memoryReveal","reveal"],
  ["#memoryNext","page"],
  ["#memory2Reveal","reveal"],
  ["#memory2Next","page"],
  ["#memory3Reveal","reveal"],
  ["#memory3Next","page"],
  ["#personalMessageNext","page"],
  ["#s1Open","reveal"],
  ["#s1Next","page"],
  ["#s2Begin","reveal"],
  ["#s2Next","page"],
  ["#s3Start","reveal"],
  [".s3-node","memory"],
  ["#s3Next","page"],
  ["#s4Begin","reveal"],
  [".s4-star","memory"],
  [".s4-object","choice"],
  ["#s4RevealNext","reveal"],
  ["#s4Capsule","reveal"],
  ["#s4CapsuleNext","page"],
  ["#s4Next","page"],
  ["#s5Begin","reveal"],
  [".s5-piece","memory"],
  ["#s5PhotoSpark","reveal"],
  ["#s5ToGate","page"],
  ["#ggStart","reveal"],
  [".gg-symbol","memory"],
  ["#ggSeed","bloom"],
  ["#ggFirefly","memory"],
  ["#ggKeyhole","unlock"],
  [".wg-flower","bloom"],
  ["#wgBloom","reveal"],
  ["#wgPlantWish","plant"],
  ["#wgContinue","page"],
  ["#s8Keepsake","gift"],
  ["#s8FocusClose","tap"],
  ["#s8Unlock","unlock"],
  ["#s8Next","page"],
  ["#bcLightFirst","candle"],
  [".bc-candle","candle"],
  ["#bcEnvelopeButton","gift"],
  ["#bcContinue","page"],
  ["#fsBegin","reveal"],
  ["#fsLight","memory"],
  ["#fsFinish","unlock"],
  ["#ceReveal","emotional"],
  ["#ceLetter","emotional"],
  ["#ceContinue","page"],
  ["#ceReplay","page"],
  [".m3v-tile","memory"]
];

function findAction(el){
  if(!(el instanceof Element))return null;
  for(const [selector,sound] of ACTIONS){
    try{if(el.closest(selector))return {selector,sound};}catch(_){}
  }
  return null;
}

/* First-touch music unlock.
   This is intentionally independent of SFX action detection:
   touching empty space, the boot screen, or any non-button area
   can unlock the BGM. It runs only once. */
document.addEventListener("pointerdown",()=>{
  unlock();
},{capture:true,once:true});

function handlePointer(e){
  const el=e.target;
  if(!(el instanceof Element)||el.id==="mimiAudioControl")return;
  const a=findAction(el);
  if(!a)return;
  console.log("[MIMI AUDIO ACTION]",a.selector,"→",a.sound);
  play(a.sound,a.selector);
}

document.addEventListener("pointerdown",handlePointer,true);

document.addEventListener("click",e=>{
  const el=e.target;
  if(!(el instanceof Element)||el.id==="mimiAudioControl")return;
  const a=findAction(el);
  if(!a)return;
  play(a.sound,a.selector);
},true);

/* ---------------------------------------------------------
   One-shot CSS animation sounds.
   Infinite/ambient animations remain silent.
--------------------------------------------------------- */
const ANIMATION_SOUNDS={
  /* Boot / opening */
  titleReveal:"reveal",
  loaderReveal:"reveal",
  unlockShine:"unlock",
  journeyReveal:"reveal",

  /* Memory reveals */
  memoryGlow:"reveal",
  memory2Glow:"reveal",
  memory3Glow:"reveal",

  /* Personal message */
  caret:"memory",

  /* Surprise 1–4 */
  s1glow:"reveal",
  s3Twinkle:"memory",
  s3Pulse:"memory",
  s3GlowA:"reveal",
  s3GlowB:"reveal",
  s4Pulse:"memory",
  s4Orbit:"memory",

  /* Surprise 5 */
  s5PhotoIn:"reveal",
  s5Shine:"memory",
  s5SparkPulse:"memory",
  s5Hint:"reveal",
  s5Nudge:"tap",

  /* Garden Gate */
  ggBloom:"bloom",
  ggFly:"memory",
  ggHint:"reveal",

  /* Wish Garden */
  wgBloom:"bloom",
  wgSeed:"plant",
  wgSpin:"memory",
  wgShake:"wrong",

  /* Surprise 8 */
  s8KeepsakeOpen:"gift",
  s8PhotoSweep:"reveal",
  s8WallIn:"reveal",
  s8NextIn:"page",

  /* Birthday */
  bcBurstMove:"memory",
  bcFlameLift:"candle",
  bcCandleLift:"candle",
  bcTouchGlow:"tap",
  bcGiftOpen:"gift",
  bcFinalIn:"emotional",

  /* Final / ending */
  fsCardIn:"emotional",
  m3vComplete:"unlock"
};

document.addEventListener("animationstart",e=>{
  const sound=ANIMATION_SOUNDS[e.animationName];
  if(!sound)return;
  try{
    if(getComputedStyle(e.target).animationIterationCount==="infinite")return;
  }catch(_){}
  console.log("[MIMI AUDIO ANIMATION]",e.animationName,"→",sound);
  play(sound,"anim:"+e.animationName);
},true);

/* ---------------------------------------------------------
   Sound control.
--------------------------------------------------------- */
function createControl(){
  if(document.getElementById("mimiAudioControl"))return;

  const b=document.createElement("button");
  b.id="mimiAudioControl";
  b.type="button";
  b.setAttribute("aria-label",muted?"Turn sound on":"Turn sound off");
  b.innerHTML='<span class="mimi-audio-icon"></span>';

  b.addEventListener("pointerdown",e=>e.stopPropagation(),true);
  b.addEventListener("click",e=>{
    e.stopPropagation();
    if(muted){
      setMuted(false);
      play("tap","audio-control");
    }else{
      setMuted(true);
    }
  });

  const s=document.createElement("style");
  s.textContent=`
    #mimiAudioControl{
      position:fixed;right:14px;bottom:14px;z-index:2147483000;
      width:38px;height:38px;border:1px solid rgba(225,201,137,.18);
      border-radius:50%;background:rgba(5,12,16,.42);
      backdrop-filter:blur(14px);-webkit-backdrop-filter:blur(14px);
      color:rgba(235,224,195,.72);display:flex;align-items:center;
      justify-content:center;opacity:.62;transition:.3s;
    }
    #mimiAudioControl:active{transform:scale(.92)}
    /* S5 has a centered CTA/footer at the bottom. Move the global sound control
       into the safe top-right zone while the S5 screen is active. */
    body.s5-audio-safe #mimiAudioControl{
      top:64px;bottom:auto;right:16px;
    }
    @media(max-height:620px){
      body.s5-audio-safe #mimiAudioControl{top:56px;right:12px}
    }
    .mimi-audio-icon{position:relative;width:15px;height:12px;display:block}
    .mimi-audio-icon:before{content:"";position:absolute;left:0;top:4px;width:4px;height:5px;
      background:currentColor;box-shadow:4px -3px 0 -1px currentColor}
    .mimi-audio-icon:after{content:"";position:absolute;left:7px;top:2px;width:7px;height:8px;
      border:1px solid currentColor;border-left:0;border-top-color:transparent;
      border-bottom-color:transparent;border-radius:0 50% 50% 0}
    #mimiAudioControl.muted .mimi-audio-icon:after{display:none}
  `;
  document.head.appendChild(s);
  document.body.appendChild(b);
  updateControl();
}

window.AudioEngine={
  unlock,
  play,
  mute:()=>setMuted(true),
  unmute:()=>setMuted(false),
  toggle:()=>setMuted(!muted),
  setVolume,
  isMuted:()=>muted,
  getVolume:()=>volume,
  isUnlocked:()=>unlocked,
  getMusicScene:()=>musicScene,
  createControl,
  startMusic,
  stopMusic,
  setScene,
  actions:ACTIONS,
  animations:ANIMATION_SOUNDS
};

if(document.readyState==="loading"){
  document.addEventListener("DOMContentLoaded",createControl,{once:true});
}else createControl();
})();
