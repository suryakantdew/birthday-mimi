/* =========================================================
   PROJECT MIMI — MAIN ENGINE
========================================================= */


/* =========================================================
   GLOBAL WAIT HELPER
========================================================= */

function wait(ms) {

    return new Promise(resolve => {

        setTimeout(resolve, ms);

    });

}


/* =========================================================
   ENGINE
========================================================= */

const Engine = {

    started: false,


    /* =====================================================
       START ENGINE
    ===================================================== */

    async start() {

        if (this.started) return;

        this.started = true;


        console.log(
            "PROJECT MIMI ENGINE STARTED"
        );


        /* Load configuration */

        if (
            typeof Config !== "undefined" &&
            typeof Config.load === "function"
        ) {

            await Config.load();

        }


        /* =================================================
           HIDDEN TEST MODE STARTUP
           If a test screen was selected, start directly
           on that screen and SKIP the normal boot/memory
           scan chain completely.
        ================================================= */

        let testScreen = null;

        try {

            testScreen =
                localStorage.getItem(
                    "PROJECT_MIMI_TEST_SCREEN"
                );

            /* Keep the test target until the requested screen
               has actually loaded. */

        }

        catch (error) {

            console.warn(
                "Test mode storage unavailable:",
                error
            );

        }


        if (testScreen) {

            console.log(
                "TEST MODE START →",
                testScreen
            );

            /*
             * Dedicated Memory 3 Challenge test:
             * load Memory 3 first so its screen environment is real,
             * then launch the exact production challenge overlay.
             * This keeps Test Mode isolated from the normal story flow.
             */
            if (
                testScreen === "__memory3Challenge"
            ) {

                const loaded =
                    await this.loadScreen("memory3");

                if (loaded) {

                    try {
                        localStorage.removeItem(
                            "PROJECT_MIMI_TEST_SCREEN"
                        );
                    } catch (error) {
                        console.warn(
                            "Unable to clear challenge test target:",
                            error
                        );
                    }

                    await wait(180);

                    if (
                        typeof openPersonalMessageWithChallenge ===
                        "function"
                    ) {
                        await openPersonalMessageWithChallenge();
                    }

                    return;

                }

                console.warn(
                    "TEST MODE LOAD FAILED → Memory 3 Challenge"
                );

                return;

            }

            const loaded =
                await this.loadScreen(
                    testScreen
                );

            if (loaded) {

                try {

                    localStorage.removeItem(
                        "PROJECT_MIMI_TEST_SCREEN"
                    );

                }

                catch (error) {

                    console.warn(
                        "Unable to clear test target:",
                        error
                    );

                }

                return;

            }

            console.warn(
                "TEST MODE LOAD FAILED → keeping target for retry:",
                testScreen
            );

            return;

        }


        /* Start with Boot */

        await this.loadScreen(
            "boot"
        );


        /* Boot owns the cinematic exit timing now. */

        /* Memory Scan is loaded by boot.js after the full opening reveal. */

    },


    /* =====================================================
       LOAD SCREEN
    ===================================================== */

    async loadScreen(name) {

        try {

            /* Never route an explicit screen request back to Boot. */
            if (!name || name === "boot" && this.started && this._leftBoot) {
                return false;
            }


            console.log(
                "Loading screen:",
                name
            );


            /*
             * MOVIE INTRO → NEXT SCREEN — TRUE NO-FLICKER HANDOFF
             *
             * The old Movie Intro is moved above the screen container
             * while the next screen loads. IMPORTANT: remove its
             * data-screen attribute while it is in the handoff layer.
             * ScreenManager.hideAll() otherwise sees it and removes
             * .active, and [data-screen]{display:none} would expose
             * body{background:#000}. That was the remaining black gap.
             *
             * This branch ONLY applies when Movie Intro is the current
             * screen. Boot and every other route use the original path.
             */
            const handoffContainer =
                document.getElementById("screenContainer");

            const movieIntroScreen =
                handoffContainer &&
                handoffContainer.querySelector(
                    "#movieIntro[data-screen].active"
                );

            let movieIntroHandoff = null;

            if(movieIntroScreen){

                movieIntroScreen.classList.remove(
                    "fade",
                    "is-exiting",
                    "is-opening",
                    "chapter-handoff"
                );

                movieIntroScreen.style.setProperty(
                    "display",
                    "flex",
                    "important"
                );
                movieIntroScreen.style.setProperty(
                    "opacity",
                    "1",
                    "important"
                );
                movieIntroScreen.style.removeProperty("transform");
                movieIntroScreen.style.removeProperty("filter");
                movieIntroScreen.style.removeProperty("visibility");

                /*
                 * Detach from ScreenManager's selector BEFORE it calls
                 * Screens.show(next). This keeps the old screen visible.
                 */
                movieIntroScreen.removeAttribute("data-screen");

                movieIntroHandoff =
                    document.createElement("div");

                movieIntroHandoff.id =
                    "mimiMovieIntroHandoff";

                Object.assign(
                    movieIntroHandoff.style,
                    {
                        position:"fixed",
                        inset:"0",
                        width:"100vw",
                        height:"100dvh",
                        zIndex:"2147483647",
                        overflow:"hidden",
                        pointerEvents:"none",
                        background:"transparent",
                        opacity:"1",
                        transform:"translate3d(0,0,0)",
                        isolation:"isolate"
                    }
                );

                document.body.appendChild(
                    movieIntroHandoff
                );

                movieIntroHandoff.appendChild(
                    movieIntroScreen
                );
            }

            const response =
                await fetch(
                    `../app/${name}.html`
                );


            if (!response.ok) {

                throw new Error(
                    `Failed to load ${name}.html`
                );

            }


            const html =
                await response.text();


            const container =
                document.getElementById(
                    "screenContainer"
                );


            if (!container) {

                console.error(
                    "screenContainer not found"
                );

                return;

            }


            /* Replace current screen */

            container.innerHTML =
                html;


            /* Tell Screen Manager */

            if (
                typeof Screens !== "undefined" &&
                typeof Screens.show === "function"
            ) {

                Screens.show(name);

            }


            /* =================================================
               SCREEN INITIALIZERS
            ================================================= */

            /* =================================================
               BOOT
            ================================================= */

            if (name === "boot" && typeof initboot === "function") {
                initboot();
            }


            /* =================================================
               MEMORY SCAN
            ================================================= */

            if (name === "memoryScan" && typeof startMemoryScan === "function") {
                startMemoryScan();
            }



            /* PASSWORD */

            if (
                name === "password" &&
                typeof initPassword ===
                "function"
            ) {

                initPassword();

            }


            /* MOVIE INTRO */

            if (
                name === "movieIntro" &&
                typeof initMovieIntro ===
                "function"
            ) {

                initMovieIntro();

            }


            /* JOURNEY */

            if (
                name === "journey" &&
                typeof initJourney ===
                "function"
            ) {

                initJourney();

            }


            /* SURPRISE 1 */

            if (
                name === "surprise1" &&
                typeof initSurprise1 ===
                "function"
            ) {

                initSurprise1();

            }


            /* SURPRISE 2 */

            if (
                name === "surprise2" &&
                typeof initSurprise2 ===
                "function"
            ) {

                initSurprise2();

            }


            /* SURPRISE 3 */

            if (
                name === "surprise3" &&
                typeof initSurprise3 ===
                "function"
            ) {

                initSurprise3();

            }


            /* SURPRISE 4 */

            if (
                name === "surprise4" &&
                typeof initSurprise4 ===
                "function"
            ) {

                initSurprise4();

            }


            /* SURPRISE 5 */

            if (
                name === "surprise5" &&
                typeof initSurprise5 ===
                "function"
            ) {

                initSurprise5();

            }


            /* GARDEN GATE */

            if (
                name === "gardenGate" &&
                typeof initGardenGate ===
                "function"
            ) {

                initGardenGate();

            }


            /* WISH GARDEN */

            if (
                name === "wishGarden" &&
                typeof initWishGarden ===
                "function"
            ) {

                initWishGarden();

            }


            /* SURPRISE 8 */

            if (
                name === "surprise8" &&
                typeof initSurprise8 ===
                "function"
            ) {

                initSurprise8();

            }


            /* BIRTHDAY CAKE */

            if (
                name === "birthdayCake" &&
                typeof initBirthdayCake ===
                "function"
            ) {

                initBirthdayCake();

            }


            /* FINAL SURPRISE */

            if (
                name === "finalSurprise" &&
                typeof initFinalSurprise ===
                "function"
            ) {

                initFinalSurprise();

            }


            /* EMOTIONAL ENDING */

            if (
                name === "emotionalEnding" &&
                typeof initEmotionalEnding ===
                "function"
            ) {

                initEmotionalEnding();

            }


            /* MEMORY 1 */

            if (
                name === "memory1" &&
                typeof initMemory1 ===
                "function"
            ) {

                initMemory1();

            }


            /* MEMORY 2 */

            if (
                name === "memory2" &&
                typeof initMemory2 ===
                "function"
            ) {

                initMemory2();

            }


            /* MEMORY 3 */

            if (
                name === "memory3" &&
                typeof initMemory3 ===
                "function"
            ) {

                initMemory3();

            }


            /* PERSONAL MESSAGE */

            if (
                name === "personalMessage" &&
                typeof initPersonalMessage ===
                "function"
            ) {

                initPersonalMessage();

            }


            console.log(
                name + " Loaded"
            );

            if (name !== "boot") {
                this._leftBoot = true;
            }

            /*
             * New screen is mounted and initialized. Let the browser
             * paint it while the old Movie Intro remains on top.
             */
            if(movieIntroHandoff){

                await new Promise(resolve =>
                    requestAnimationFrame(() =>
                        requestAnimationFrame(resolve)
                    )
                );

                const oldLayer =
                    movieIntroHandoff;

                oldLayer.animate(
                    [
                        {
                            opacity:1,
                            transform:"translate3d(0,0,0) scale(1)"
                        },
                        {
                            opacity:0,
                            transform:"translate3d(0,0,0) scale(1.006)"
                        }
                    ],
                    {
                        duration:420,
                        easing:"cubic-bezier(.22,1,.36,1)",
                        fill:"forwards"
                    }
                ).finished.then(
                    () => oldLayer.remove(),
                    () => oldLayer.remove()
                );
            }

            try{
                if(
                    typeof AudioEngine !== "undefined" &&
                    typeof AudioEngine.setScene === "function"
                ){
                    AudioEngine.setScene(name);
                }
            }catch(err){
                console.warn(
                    "[MIMI MUSIC] Scene sync failed",
                    name,
                    err
                );
            }

            return true;

        }

        catch (error) {

            console.error(
                "Screen loading error:",
                error
            );

            return false;

        }

  }

};


/* =========================================================
   START ENGINE AFTER DOM READY
========================================================= */

document.addEventListener(
    "DOMContentLoaded",
    () => {

        Engine.start();

        initHiddenTestMode();

    }
);



/* =========================================================
   MEMORY 1
========================================================= */

function initMemory1() {

    const button = document.getElementById("memoryReveal");
    const card = document.getElementById("memoryRevealCard");
    const content = document.querySelector(".memory1-content");
    const screen = document.getElementById("memory1");

    if(!button || !card || !screen) return;

    let opened = false;

    const sound=(name,key)=>{
        try{
            if(typeof AudioEngine !== "undefined" &&
               typeof AudioEngine.play === "function"){
                AudioEngine.play(name,key);
            }
        }catch(_){}
    };

    button.addEventListener("pointerup", async (event)=>{
        event.preventDefault();
        event.stopPropagation();

        if(opened || button.disabled) return;
        opened=true;
        button.disabled=true;

        sound("reveal","memory1-reveal");

        button.animate(
            [
                {transform:"scale(1)"},
                {transform:"scale(.955)"},
                {transform:"scale(1.018)"},
                {transform:"scale(1)"}
            ],
            {
                duration:360,
                easing:"cubic-bezier(.18,.8,.22,1)"
            }
        );

        await wait(190);

        button.classList.add("memory1-triggered");

        if(content) content.classList.add("memory-open");

        await wait(260);

        card.classList.add("revealed");
        screen.classList.add("memory-revealed");
        card.setAttribute("aria-hidden","false");

        const image=document.getElementById("memory1Image");
        if(image){
            const revealImage=()=>image.classList.add("loaded");
            if(image.complete) {
                requestAnimationFrame(revealImage);
            } else {
                image.addEventListener("load",revealImage,{once:true});
            }
        }

        const nextButton=document.querySelector(".memory1-next");

        if(nextButton){
            nextButton.addEventListener("pointerup",async (event)=>{
                event.preventDefault();
                event.stopPropagation();

                if(nextButton.disabled) return;
                nextButton.disabled=true;

                sound("page","memory1-next");

                nextButton.animate(
                    [
                        {transform:"scale(1)"},
                        {transform:"scale(.96)"},
                        {transform:"scale(1.012)"},
                        {transform:"scale(1)"}
                    ],
                    {
                        duration:300,
                        easing:"cubic-bezier(.18,.8,.22,1)"
                    }
                );

                await wait(170);

                screen.classList.add("fade");

                await wait(420);

                await Engine.loadScreen("memory2");
            },{once:true});
        }
    },{passive:false});
}

function initMemory2() {

    const button = document.getElementById("memory2Reveal");
    const card = document.getElementById("memory2Card");
    const nextButton = document.getElementById("memory2Next");
    const screen = document.getElementById("memory2");

    if(!button || !card || !screen) return;

    let opened = false;

    const sound=(name,key)=>{
        try{
            if(typeof AudioEngine !== "undefined" &&
               typeof AudioEngine.play === "function"){
                AudioEngine.play(name,key);
            }
        }catch(_){}
    };

    button.addEventListener("pointerup", async (event)=>{
        event.preventDefault();
        event.stopPropagation();

        if(opened || button.disabled) return;
        opened=true;
        button.disabled=true;

        sound("reveal","memory2-reveal");

        button.animate(
            [
                {transform:"scale(1)"},
                {transform:"scale(.955)"},
                {transform:"scale(1.018)"},
                {transform:"scale(1)"}
            ],
            {
                duration:360,
                easing:"cubic-bezier(.18,.8,.22,1)"
            }
        );

        /*
         * Seamless reveal:
         * Start the cinematic background + card entrance together.
         * The previous 210ms + 90ms delay created the short empty/dark
         * gap seen after the CTA press.
         */
        await wait(110);

        screen.classList.add("memory2-revealed");
        card.classList.add("revealed");
        card.setAttribute("aria-hidden","false");

        const image=document.getElementById("memory2Image");

        if(image){
            const focusImage=()=>{
                image.classList.add("loaded");
            };

            if(image.complete){
                requestAnimationFrame(focusImage);
            }else{
                image.addEventListener("load",focusImage,{once:true});
            }
        }

        await wait(980);

        if(nextButton){
            nextButton.classList.add("visible");

            nextButton.addEventListener("pointerup",async (event)=>{
                event.preventDefault();
                event.stopPropagation();

                if(nextButton.disabled) return;
                nextButton.disabled=true;

                sound("page","memory2-next");

                nextButton.animate(
                    [
                        {transform:"scale(1)"},
                        {transform:"scale(.96)"},
                        {transform:"scale(1.012)"},
                        {transform:"scale(1)"}
                    ],
                    {
                        duration:300,
                        easing:"cubic-bezier(.18,.8,.22,1)"
                    }
                );

                await wait(170);

                screen.classList.add("fade");

                await wait(420);

                await Engine.loadScreen("memory3");
            },{once:true});
        }
    },{passive:false});
}

function initMemory3() {

    console.log("Memory 3 Loaded");

    const button=document.getElementById("memory3Reveal");
    const photoWrap=document.getElementById("memory3PhotoWrap");
    const caption=document.getElementById("memory3Caption");
    const nextButton=document.getElementById("memory3Next");
    const screen=document.getElementById("memory3");

    if(!button || !photoWrap || !caption || !screen){
        console.warn("Memory 3 elements not found");
        return;
    }

    let opened=false;

    const sound=(name,key)=>{
        try{
            if(typeof AudioEngine!=="undefined" &&
               typeof AudioEngine.play==="function"){
                AudioEngine.play(name,key);
            }
        }catch(_){}
    };

    button.addEventListener("pointerup",async event=>{
        event.preventDefault();
        event.stopPropagation();

        if(opened || button.disabled) return;
        opened=true;
        button.disabled=true;

        sound("reveal","memory3-reveal");

        button.animate(
            [
                {transform:"scale(1)"},
                {transform:"scale(.955)"},
                {transform:"scale(1.018)"},
                {transform:"scale(1)"}
            ],
            {duration:360,easing:"cubic-bezier(.18,.8,.22,1)"}
        );

        /*
         * TRUE CONTINUOUS REVEAL:
         * Start the photo while the intro is still visible, then remove
         * the intro only after the photo has begun painting. This creates
         * an overlap instead of an exposed dark/empty frame.
         */
        await wait(90);

        photoWrap.classList.add("visible");

        await wait(180);

        screen.classList.add("memory3-revealed");
        button.style.opacity="0";
        button.style.transform="translateY(10px)";
        button.style.pointerEvents="none";

        await wait(650);
        caption.classList.add("visible");

        await wait(700);

        if(nextButton){
            nextButton.classList.add("visible");

            nextButton.addEventListener("pointerup",async event=>{
                event.preventDefault();
                event.stopPropagation();

                if(nextButton.disabled) return;
                nextButton.disabled=true;

                sound("page","memory3-next");

                nextButton.animate(
                    [
                        {transform:"scale(1)"},
                        {transform:"scale(.96)"},
                        {transform:"scale(1.012)"},
                        {transform:"scale(1)"}
                    ],
                    {duration:300,easing:"cubic-bezier(.18,.8,.22,1)"}
                );

                await wait(170);
                screen.classList.add("fade");
                await wait(650);

                /*
                 * Personal Message is the intended destination here.
                 * Use the cinematic challenge when it exists; otherwise
                 * fall back safely to the real screen loader. This avoids
                 * the ReferenceError that was stopping the flow.
                 */
                /* Open the original Memory 3 → Personal Message challenge. */
                await openPersonalMessageWithChallenge();
            },{once:true});
        }

    },{passive:false});
}


function initHiddenTestMode() {

    let tapCount = 0;

    let tapTimer = null;

    const TAP_LIMIT = 5;

    const TAP_WINDOW = 1800;

    let menuOpen = false;


    /* -----------------------------------------------------
       Hidden trigger area
    ----------------------------------------------------- */

    const trigger = document.createElement(
        "button"
    );

    trigger.type = "button";

    trigger.setAttribute(
        "aria-label",
        "Hidden test mode"
    );

    trigger.style.position = "fixed";

    trigger.style.top = "0";

    trigger.style.left = "0";

    trigger.style.width = "82px";

    trigger.style.height = "82px";

    trigger.style.padding = "0";

    trigger.style.margin = "0";

    trigger.style.border = "0";

    trigger.style.background = "transparent";

    trigger.style.opacity = "0";

    trigger.style.zIndex = "2147483646";

    trigger.style.cursor = "default";

    trigger.style.webkitTapHighlightColor =
        "transparent";

    document.body.appendChild(
        trigger
    );


    /* -----------------------------------------------------
       Create menu
    ----------------------------------------------------- */

    const overlay = document.createElement(
        "div"
    );

    overlay.id = "mimiHiddenTestMode";

    overlay.style.position = "fixed";

    overlay.style.inset = "0";

    overlay.style.zIndex = "2147483647";

    overlay.style.display = "none";

    overlay.style.alignItems = "center";

    overlay.style.justifyContent = "center";

    overlay.style.padding = "22px";

    overlay.style.boxSizing = "border-box";

    overlay.style.background =
        "rgba(3,7,15,.94)";

    overlay.style.backdropFilter =
        "blur(18px)";

    overlay.style.webkitBackdropFilter =
        "blur(18px)";


    const panel = document.createElement(
        "div"
    );

    panel.style.width = "min(92vw,430px)";

    panel.style.maxHeight = "88vh";

    panel.style.overflowY = "auto";

    panel.style.boxSizing = "border-box";

    panel.style.padding = "24px 18px";

    panel.style.border =
        "1px solid rgba(232,199,125,.28)";

    panel.style.borderRadius = "22px";

    panel.style.background =
        "linear-gradient(145deg,rgba(26,35,52,.98),rgba(9,16,29,.98))";

    panel.style.boxShadow =
        "0 30px 90px rgba(0,0,0,.55)";

    panel.style.color = "#fff";

    panel.style.fontFamily =
        'Georgia,"Times New Roman",serif';


    const title = document.createElement(
        "div"
    );

    title.textContent =
        "PROJECT MIMI";

    title.style.textAlign = "center";

    title.style.letterSpacing = "5px";

    title.style.fontSize = "11px";

    title.style.color = "#e4c27c";

    title.style.marginBottom = "7px";


    const subtitle = document.createElement(
        "div"
    );

    subtitle.textContent =
        "PRIVATE TEST MODE";

    subtitle.style.textAlign = "center";

    subtitle.style.fontSize = "24px";

    subtitle.style.marginBottom = "20px";


    const note = document.createElement(
        "div"
    );

    note.textContent =
        "Choose any screen to test directly.";

    note.style.textAlign = "center";

    note.style.fontSize = "13px";

    note.style.color =
        "rgba(255,255,255,.55)";

    note.style.marginBottom = "18px";


    const list = document.createElement(
        "div"
    );

    list.style.display = "grid";

    list.style.gap = "9px";


    const screens = [

        ["boot", "Boot"],

        ["memoryScan", "Memory Scan"],

        ["password", "Password"],

        ["movieIntro", "Movie Intro"],

        ["journey", "Journey"],

        ["surprise1", "Surprise 1"],

        ["memory1", "Memory 1"],

        ["memory2", "Memory 2"],

        ["memory3", "Memory 3"],

        ["__memory3Challenge", "Memory 3 Challenge"],

        ["personalMessage", "Personal Message"],

        ["surprise2", "Surprise 2"],

        ["surprise3", "Surprise 3"],

        ["surprise4", "Surprise 4"],

        ["surprise5", "Surprise 5"],

        ["gardenGate", "Garden Gate"],

        ["wishGarden", "Wish Garden"],

        ["surprise8", "Hidden Surprise"],

        ["birthdayCake", "Birthday Cake"],

        ["finalSurprise", "Final Surprise"],

        ["emotionalEnding", "Emotional Ending"]

    ];


    /*
       STORY NUMBERING
       The hidden Test Mode list is an internal screen registry, so its
       array index does not match the public 01–10 story numbers.
       Keep utility/system screens unnumbered and make the actual story
       screens use the same numbers shown inside their screens.
    */
    const storyNumbers = {
        surprise1: "01",
        surprise2: "02",
        surprise3: "03",
        surprise4: "04",
        surprise5: "05",
        gardenGate: "06",
        wishGarden: "07",
        surprise8: "08",
        finalSurprise: "09",
        emotionalEnding: "10"
    };


    screens.forEach(
        ([screenName, label]) => {

            const item =
                document.createElement("button");

            item.type = "button";

            const storyNumber =
                storyNumbers[screenName] || "—";

            item.textContent =
                storyNumber +
                "   " +
                label;

            item.style.width = "100%";

            item.style.minHeight = "48px";

            item.style.padding = "12px 15px";

            item.style.border =
                "1px solid rgba(232,199,125,.18)";

            item.style.borderRadius = "13px";

            item.style.background =
                "rgba(255,255,255,.045)";

            item.style.color = "#f3dfb0";

            item.style.textAlign = "left";

            item.style.font =
                '600 14px Georgia,"Times New Roman",serif';

            item.style.cursor = "pointer";

            item.style.transition =
                "transform .18s ease, background .18s ease";


            item.addEventListener(
                "pointerdown",
                () => {

                    item.style.transform =
                        "scale(.98)";

                }
            );


            item.addEventListener(
                "pointerup",
                async () => {

                    item.style.transform =
                        "scale(1)";

                    closeMenu();

                    await wait(120);


                    /* =================================================
                       IMPORTANT:
                       Reload the app with a one-time test target.

                       This completely resets old timers/callbacks
                       from Boot / Memory Scan. Without this, a
                       background memoryScan callback can fire later
                       and interfere with the directly tested screen.
                    ================================================= */

                    try {

                        localStorage.setItem(
                            "PROJECT_MIMI_TEST_SCREEN",
                            screenName
                        );

                    }

                    catch (error) {

                        console.error(
                            "Unable to save test screen:",
                            error
                        );

                        return;

                    }


                    window.location.reload();

                }
            );


            list.appendChild(item);

        }
    );


    const close = document.createElement(
        "button"
    );

    close.type = "button";

    close.textContent = "Close Test Mode";

    close.style.width = "100%";

    close.style.minHeight = "46px";

    close.style.marginTop = "16px";

    close.style.border =
        "1px solid rgba(255,255,255,.12)";

    close.style.borderRadius = "999px";

    close.style.background =
        "transparent";

    close.style.color =
        "rgba(255,255,255,.55)";

    close.style.font =
        '14px Georgia,"Times New Roman",serif';

    close.style.cursor = "pointer";

    close.onclick = () => {

        closeMenu();

    };


    panel.appendChild(title);

    panel.appendChild(subtitle);

    panel.appendChild(note);

    panel.appendChild(list);

    panel.appendChild(close);

    overlay.appendChild(panel);

    document.body.appendChild(
        overlay
    );


    /* -----------------------------------------------------
       Open / close
    ----------------------------------------------------- */

    function openMenu() {

        if (menuOpen) return;

        menuOpen = true;

        overlay.style.display = "flex";

        document.body.style.overflow =
            "hidden";

    }


    function closeMenu() {

        menuOpen = false;

        overlay.style.display = "none";

        document.body.style.overflow =
            "";

    }


    /* -----------------------------------------------------
       Five quick taps
    ----------------------------------------------------- */

    trigger.addEventListener(
        "click",
        () => {

            tapCount++;

            clearTimeout(tapTimer);


            tapTimer = setTimeout(
                () => {

                    tapCount = 0;

                },
                TAP_WINDOW
            );


            if (
                tapCount >= TAP_LIMIT
            ) {

                tapCount = 0;

                clearTimeout(tapTimer);

                openMenu();

            }

        }
    );


    /* -----------------------------------------------------
       Escape closes menu
    ----------------------------------------------------- */

    document.addEventListener(
        "keydown",
        event => {

            if (
                event.key === "Escape" &&
                menuOpen
            ) {

                closeMenu();

            }

        }
    );


    console.log(
        "Hidden Test Mode Ready — tap top-left 5 times"
    );

}


/* =========================================================
   PROJECT MIMI — STABLE SCREEN HANDOFF
   Boot -> Memory Scan
========================================================= */
window.MIMI_GOTO_SCREEN = async function(name){
    if (!name || name === "boot") return false;

    try{
        if (typeof Engine !== "undefined" &&
            typeof Engine.loadScreen === "function") {
            return await Engine.loadScreen(name);
        }
    }catch(err){
        console.error("[MIMI HANDOFF] Failed:", name, err);
    }
    return false;
};


async function openPersonalMessageWithChallenge() {

    const old = document.getElementById("mimiMemory3Bridge");
    if (old) old.remove();

    const bridge = document.createElement("div");
    bridge.id = "mimiMemory3Bridge";

    bridge.innerHTML = `
        <div class="m3v-noise"></div>
        <div class="m3v-stars"><i></i><i></i><i></i><i></i><i></i><i></i></div>

        <main class="m3v-content">
            <div class="m3v-mark"><span></span><b>✦</b><span></span></div>

            <p class="m3v-kicker">THE NEXT PAGE IS LOCKED</p>

            <h2 id="m3vTitle">
                There is one more door.<br>
                <em>Can you remember the key?</em>
            </h2>

            <p id="m3vText">
                Watch the lights carefully.<br>
                They won't stay for long.
            </p>

            <div id="m3vGame" class="m3v-game"></div>

            <div id="m3vProgress" class="m3v-progress"></div>

            <p id="m3vHint" class="m3v-hint">get ready</p>
        </main>
    `;

    const style = document.createElement("style");
    style.id = "mimiMemory3VaultStyle";

    style.textContent = `
        #mimiMemory3Bridge{
            position:fixed;
            inset:0;
            z-index:999999;
            overflow:hidden;
            display:flex;
            align-items:center;
            justify-content:center;
            background:
                radial-gradient(circle at 50% 42%,rgba(225,199,126,.12),transparent 19%),
                radial-gradient(circle at 15% 80%,rgba(75,118,125,.09),transparent 28%),
                linear-gradient(145deg,#020507,#071113 57%,#020606);
            color:#eee9dc;
            font-family:Georgia,"Times New Roman",serif;
            opacity:0;
            animation:m3vIn .8s cubic-bezier(.2,.8,.2,1) forwards;
            isolation:isolate;
        }

        #mimiMemory3Bridge *{box-sizing:border-box}

        .m3v-noise{
            position:absolute;
            inset:0;
            opacity:.028;
            pointer-events:none;
            background:repeating-linear-gradient(
                0deg,
                transparent 0,
                transparent 3px,
                rgba(255,255,255,.15) 4px
            );
        }

        .m3v-stars{
            position:absolute;
            inset:0;
            pointer-events:none;
        }

        .m3v-stars i{
            position:absolute;
            width:2px;
            height:2px;
            border-radius:50%;
            background:#dfca89;
            box-shadow:0 0 13px #dfca89;
            opacity:.10;
            animation:m3vStar 5s ease-in-out infinite;
        }

        .m3v-stars i:nth-child(1){left:13%;top:22%}
        .m3v-stars i:nth-child(2){left:82%;top:18%;animation-delay:1s}
        .m3v-stars i:nth-child(3){left:20%;top:78%;animation-delay:2s}
        .m3v-stars i:nth-child(4){left:79%;top:72%;animation-delay:3s}
        .m3v-stars i:nth-child(5){left:52%;top:13%;animation-delay:1.5s}
        .m3v-stars i:nth-child(6){left:67%;top:54%;animation-delay:2.5s}

        .m3v-content{
            position:relative;
            z-index:2;
            width:min(92vw,430px);
            text-align:center;
            display:flex;
            flex-direction:column;
            align-items:center;
        }

        .m3v-mark{
            display:flex;
            align-items:center;
            gap:13px;
            width:150px;
            margin-bottom:20px;
        }

        .m3v-mark span{
            flex:1;
            height:1px;
            background:linear-gradient(90deg,transparent,rgba(220,198,135,.28));
        }

        .m3v-mark span:last-child{
            background:linear-gradient(90deg,rgba(220,198,135,.28),transparent);
        }

        .m3v-mark b{
            color:#dec477;
            font-size:15px;
            font-weight:normal;
            text-shadow:0 0 24px rgba(222,196,119,.8);
            animation:m3vPulse 2.7s infinite;
        }

        .m3v-kicker{
            margin:0;
            color:rgba(225,211,176,.30);
            font-size:7px;
            letter-spacing:.43em;
        }

        .m3v-content h2{
            margin:20px 0 12px;
            font-size:28px;
            line-height:1.16;
            font-weight:normal;
        }

        .m3v-content h2 em{
            color:#ddc57d;
            font-style:italic;
        }

        .m3v-content #m3vText{
            margin:0;
            color:rgba(235,231,218,.50);
            font-size:12.5px;
            line-height:1.75;
        }

        .m3v-game{
            width:276px;
            height:276px;
            margin:20px auto 8px;
            display:grid;
            grid-template-columns:repeat(3,1fr);
            gap:9px;
            position:relative;
        }

        .m3v-tile{
            appearance:none;
            border:1px solid rgba(222,197,124,.18);
            border-radius:15px;
            background:
                linear-gradient(145deg,
                    rgba(255,255,255,.024),
                    rgba(255,255,255,.008));
            color:rgba(225,210,170,.35);
            cursor:pointer;
            position:relative;
            overflow:hidden;
            transition:
                transform .20s ease,
                background .22s ease,
                border-color .22s ease,
                box-shadow .22s ease,
                color .22s ease;
        }

        .m3v-tile::after{
            content:"";
            position:absolute;
            inset:12px;
            border-radius:11px;
            border:1px solid rgba(255,255,255,.025);
            pointer-events:none;
        }

        .m3v-tile span{
            position:relative;
            z-index:2;
            display:block;
            font-size:17px;
            opacity:.7;
            transition:transform .22s ease;
        }

        .m3v-tile.flash{
            background:
                radial-gradient(circle,
                    rgba(229,203,128,.32),
                    rgba(229,203,128,.07) 58%,
                    transparent 75%);
            border-color:rgba(229,203,128,.80);
            box-shadow:
                0 0 34px rgba(229,203,128,.22),
                inset 0 0 25px rgba(229,203,128,.07);
            color:#f0d994;
            transform:scale(1.045);
        }

        .m3v-tile.flash span{
            transform:scale(1.35);
            opacity:1;
        }

        .m3v-tile.selected{
            background:rgba(224,198,123,.085);
            border-color:rgba(224,198,123,.52);
            color:#e6d18e;
        }

        .m3v-tile.wrong{
            animation:m3vShake .34s ease;
            border-color:rgba(220,100,90,.65);
        }

        .m3v-tile.locked{
            pointer-events:none;
        }

        .m3v-progress{
            height:8px;
            min-width:100px;
            display:flex;
            justify-content:center;
            gap:7px;
            margin:2px 0 6px;
        }

        .m3v-dot{
            width:7px;
            height:7px;
            border-radius:50%;
            border:1px solid rgba(224,198,123,.38);
            transition:.25s ease;
        }

        .m3v-dot.on{
            background:#dfc77d;
            box-shadow:0 0 14px rgba(224,198,123,.75);
            transform:scale(1.18);
        }

        .m3v-hint{
            min-height:18px;
            margin:0;
            color:rgba(225,211,177,.34);
            font-size:8px;
            letter-spacing:.24em;
            text-transform:uppercase;
        }

        .m3v-hint.good{color:rgba(225,202,132,.80)}
        .m3v-hint.bad{color:rgba(225,145,135,.72)}

        .m3v-complete{
            animation:m3vComplete 1.1s ease forwards;
        }

        .m3v-fade{
            animation:m3vOut .9s ease forwards!important;
        }

        @keyframes m3vIn{
            from{opacity:0;transform:scale(1.025)}
            to{opacity:1;transform:scale(1)}
        }

        @keyframes m3vOut{
            to{opacity:0;transform:scale(1.018)}
        }

        @keyframes m3vStar{
            0%,100%{opacity:.06;transform:translateY(0)}
            50%{opacity:.38;transform:translateY(-10px)}
        }

        @keyframes m3vPulse{
            0%,100%{opacity:.42;transform:scale(.86)}
            50%{opacity:1;transform:scale(1.14)}
        }

        @keyframes m3vShake{
            0%,100%{transform:translateX(0)}
            25%{transform:translateX(-8px)}
            75%{transform:translateX(8px)}
        }

        @keyframes m3vComplete{
            0%{transform:scale(1);opacity:1}
            50%{transform:scale(1.035);opacity:.78}
            100%{transform:scale(.72);opacity:0}
        }

        @media(max-width:420px){
            .m3v-content h2{font-size:26px}
            .m3v-game{
                width:258px;
                height:258px;
                gap:8px;
            }
            .m3v-tile{border-radius:13px}
        }

        @media(max-height:760px){
            .m3v-game{
                width:235px;
                height:235px;
                margin-top:14px;
            }
            .m3v-content h2{margin-top:15px}
        }

        @media(prefers-reduced-motion:reduce){
            #mimiMemory3Bridge *{
                animation-duration:.01ms!important;
                transition-duration:.01ms!important;
            }
        }
    `;

    document.head.appendChild(style);
    document.body.appendChild(bridge);

    const title=bridge.querySelector("#m3vTitle");
    const text=bridge.querySelector("#m3vText");
    const game=bridge.querySelector("#m3vGame");
    const progress=bridge.querySelector("#m3vProgress");
    const hint=bridge.querySelector("#m3vHint");

    const waitFor=ms=>new Promise(resolve=>setTimeout(resolve,ms));

    const rounds=[
        {
            length:4,
            flash:560,
            gap:170,
            title:"Remember the<br><em>first pattern.</em>",
            text:"Watch carefully.<br>Then recreate it from memory."
        },
        {
            length:5,
            flash:440,
            gap:125,
            title:"You remembered.<br><em>Now it gets harder.</em>",
            text:"Five lights this time.<br>They will move faster."
        },
        {
            length:6,
            flash:355,
            gap:95,
            title:"Last lock.<br><em>No second guessing.</em>",
            text:"Six lights.<br>Trust what you just saw."
        }
    ];

    const symbols=["✦","✧","◇","·","✣","✺","◌","◆","✧"];

    function createSequence(length,roundIndex){
        const result=[];
        let last=-1;

        // No immediate duplicate; enough spatial variation.
        while(result.length<length){
            let next=Math.floor(Math.random()*9);
            if(next===last) continue;
            if(roundIndex>0 && result.length>1 && next===result[result.length-2]) continue;
            result.push(next);
            last=next;
        }

        return result;
    }

    async function playRound(roundIndex, retry=false){

        const cfg=rounds[roundIndex];
        const sequence=createSequence(cfg.length,roundIndex);

        title.innerHTML=cfg.title;
        text.innerHTML=cfg.text;

        game.innerHTML=Array.from({length:9},(_,i)=>`
            <button class="m3v-tile locked" data-i="${i}" aria-label="memory tile ${i+1}">
                <span>${symbols[i]}</span>
            </button>
        `).join("");

        progress.innerHTML=sequence.map((_,i)=>
            `<i class="m3v-dot" data-dot="${i}"></i>`
        ).join("");

        const tiles=[...game.querySelectorAll(".m3v-tile")];
        const dots=[...progress.querySelectorAll(".m3v-dot")];

        hint.className="m3v-hint";
        hint.textContent=retry ? "watch again — slower this time" : "watch carefully";

        await waitFor(700);

        // Give a short cinematic count-in.
        for(const count of ["3","2","1"]){
            hint.textContent=count;
            await waitFor(360);
        }

        hint.textContent="remember the path";
        await waitFor(220);

        // Play the sequence.
        for(const index of sequence){
            const tile=tiles[index];
            tile.classList.add("flash");
            await waitFor(cfg.flash);
            tile.classList.remove("flash");
            await waitFor(cfg.gap);
        }

        // Hide all clues and enable input.
        tiles.forEach(tile=>tile.classList.remove("locked"));
        hint.textContent="your turn";

        let input=[];
        let busy=false;

        const fail=async(tile)=>{
            busy=true;
            tile.classList.add("wrong");
            if (typeof AudioEngine !== "undefined") AudioEngine.play("wrong");
            hint.className="m3v-hint bad";
            hint.textContent="not quite... the pattern is returning";

            await waitFor(520);

            input=[];
            dots.forEach(d=>d.classList.remove("on"));
            tiles.forEach(t=>{
                t.classList.remove("selected","wrong");
                t.classList.add("locked");
            });

            await waitFor(240);

            // Replay the same pattern, slightly slower, instead of changing it.
            hint.className="m3v-hint";
            hint.textContent="watch one more time";

            for(const index of sequence){
                const t=tiles[index];
                t.classList.add("flash");
                await waitFor(Math.min(cfg.flash+90,650));
                t.classList.remove("flash");
                await waitFor(cfg.gap+30);
            }

            tiles.forEach(t=>t.classList.remove("locked"));
            hint.textContent="your turn";
            busy=false;
        };

        tiles.forEach(tile=>{
            tile.onclick=async()=>{
                if(busy || tile.classList.contains("locked")) return;

                const index=Number(tile.dataset.i);
                const expected=sequence[input.length];

                if(index!==expected){
                    await fail(tile);
                    return;
                }

                input.push(index);
                tile.classList.add("selected");
                if (typeof AudioEngine !== "undefined") AudioEngine.play("tap");
                dots[input.length-1].classList.add("on");

                if(input.length===sequence.length){

                    busy=true;
                    tiles.forEach(t=>t.classList.add("locked"));

                    hint.className="m3v-hint good";
                    if (typeof AudioEngine !== "undefined") AudioEngine.play("correct");
                    hint.textContent=
                        roundIndex===2
                        ? "the final lock is open"
                        : "correct — next lock opening";

                    game.classList.add("m3v-complete");

                    await waitFor(1050);

                    if(roundIndex<rounds.length-1){
                        game.classList.remove("m3v-complete");
                        await waitFor(350);
                        await playRound(roundIndex+1,false);
                        return;
                    }

                    if (typeof AudioEngine !== "undefined") AudioEngine.play("unlock");

                    title.innerHTML="The door is open.<br><em>Come inside.</em>";
                    text.innerHTML=
                        "There was something waiting here<br>that I wanted you to read.";

                    game.innerHTML=`
                        <div style="
                            width:82px;height:82px;border-radius:50%;
                            display:flex;align-items:center;justify-content:center;
                            border:1px solid rgba(224,198,123,.38);
                            color:#e4ca7e;font-size:34px;
                            background:radial-gradient(circle,rgba(224,198,123,.16),transparent 68%);
                            box-shadow:0 0 55px rgba(224,198,123,.18);
                            animation:m3vPulse 1.8s infinite;
                        ">✦</div>
                    `;

                    progress.innerHTML="";
                    hint.textContent="personal message";

                    /*
                     * IMPORTANT:
                     * Keep the vault overlay on screen while the next
                     * screen is loading. The old Memory 3 DOM is hidden
                     * underneath, so it can never flash back between
                     * the unlock and Personal Message.
                     */
                    bridge.style.transition =
                        "opacity .78s cubic-bezier(.22,1,.36,1), transform .78s cubic-bezier(.22,1,.36,1)";
                    bridge.style.opacity = "1";

                    await waitFor(1050);

                    const loaded =
                        await Engine.loadScreen(
                            "personalMessage"
                        );

                    if (loaded) {

                        /*
                         * PERSONAL MESSAGE HANDOFF — FINAL NO-BLANK GATE
                         *
                         * Do NOT use the page's animation class as the
                         * readiness signal. The class can exist while the
                         * letter is still visually empty.
                         *
                         * Wait for the FIRST REAL CHARACTER to be painted
                         * inside the first page while the completed vault
                         * remains in front. Only then cross-fade to the
                         * letter. This removes the exposed blank-paper
                         * frame completely.
                         */
                        const readyDeadline =
                            performance.now() + 2600;

                        let firstCharacterPainted = false;

                        while (
                            performance.now() < readyDeadline
                        ) {

                            const firstPage =
                                document.querySelector(
                                    "#personalMessage .letter-page"
                                );

                            if (firstPage) {

                                const firstContent =
                                    firstPage.querySelector(
                                        ".letter-content"
                                    );

                                if (firstContent) {

                                    /*
                                     * The typing engine progressively writes
                                     * text nodes. Ignore decorative whitespace
                                     * and look for an actual alphabetic/emoji
                                     * character.
                                     */
                                    const visibleText =
                                        (firstContent.textContent || "")
                                            .replace(/\s+/g, "");

                                    const pageStyle =
                                        getComputedStyle(firstPage);

                                    if (
                                        visibleText.length > 2 &&
                                        parseFloat(pageStyle.opacity || "0") > .35
                                    ) {
                                        firstCharacterPainted = true;
                                        break;
                                    }
                                }
                            }

                            await waitFor(32);
                        }

                        /*
                         * Give the browser one extra paint cycle so the
                         * first character is definitely on the compositor.
                         */
                        await new Promise(resolve =>
                            requestAnimationFrame(() =>
                                requestAnimationFrame(resolve)
                            )
                        );

                        /*
                         * Very short overlap: the vault still covers the
                         * letter while the first line settles, then the
                         * cross-fade reveals it.
                         */
                        await waitFor(
                            firstCharacterPainted ? 90 : 0
                        );

                        bridge.classList.add(
                            "m3v-fade"
                        );

                        await waitFor(900);

                        bridge.remove();
                        style.remove();

                    } else {

                        /* If loading fails, keep the vault visible
                           instead of exposing Memory 3 again. */
                        bridge.classList.remove(
                            "m3v-fade"
                        );

                        hint.className =
                            "m3v-hint bad";

                        hint.textContent =
                            "the next page needs another moment";

                    }
                }
            };
        });
    }

    await playRound(0,false);
}
