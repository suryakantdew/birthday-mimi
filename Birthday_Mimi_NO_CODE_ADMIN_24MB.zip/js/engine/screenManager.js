/**
 * ==========================================
 * PROJECT MIMI v2
 * Screen Manager
 * Version : 1.0
 * ==========================================
 */

class ScreenManager {

    constructor() {

        this.currentScreen = null;

    }

    /**
     * Hide all screens
     */
    hideAll() {

        document.querySelectorAll("[data-screen]")
        .forEach(screen => {

            screen.classList.remove("active");

        });

    }

    /**
     * Show a screen
     * @param {string} screenId
     */
    show(screenId) {

        this.hideAll();

        const screen =
        document.getElementById(screenId);

        if (!screen) {

            console.error(
                `Screen "${screenId}" not found.`
            );

            return;

        }

        screen.classList.add("active");

        this.currentScreen = screenId;

        console.log(
            `Screen Loaded : ${screenId}`
        );

    }

    /**
     * Get Current Screen
     */
    getCurrent() {

        return this.currentScreen;

    }

}

const Screens = new ScreenManager();